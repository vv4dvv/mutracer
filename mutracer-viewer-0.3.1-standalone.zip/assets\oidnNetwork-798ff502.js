import{V as Jr}from"./index-d869bd6d.js";class en{dims=[];paddedDims=[];layout="x";dataType="Float32";getByteSize(){let e=1;for(const t of this.paddedDims)e*=t;return this.dataType==="Float32"?e*=4:this.dataType==="Float16"&&(e*=2),e}}class tn{desc;data;constructor(e,t){this.desc=e,this.data=t}}class rn{_view;offset=0;constructor(e){this._view=e}read(e){const t=this._view,i=this.offset;switch(this.offset+=e,e){case 1:return t.getUint8(i);case 2:return t.getUint16(i,!0);case 4:return t.getUint32(i,!0);case 8:return Number(t.getBigUint64(i,!0));default:throw new Error("unsupported read size")}}}function nn(r){const e=new Uint8Array(r),t=new rn(new DataView(r));if(t.read(2)!==16855)throw new Error("invalid or corrupted weights blob");const n=t.read(1);if(t.read(1),n!==2)throw new Error("unsupported weights blob version");const o=t.read(8);t.offset=o;const a=t.read(4),s=new Map;for(let u=0;u<a;++u){const l=new en,p=t.read(2),c=new TextDecoder().decode(e.subarray(t.offset,t.offset+p));t.offset+=p;const d=t.read(1);for(let $=0;$<d;++$)l.dims.push(t.read(4));l.paddedDims=[...l.dims],new TextDecoder().decode(e.subarray(t.offset,t.offset+d))==="oihw"&&(l.layout="oihw"),t.offset+=d;const g=String.fromCharCode(t.read(1));if(g==="f")l.dataType="Float32";else if(g==="h")l.dataType="Float16";else throw new Error("invalid tensor data type");const h=t.read(8),_=e.slice(h,h+l.getByteSize());s.set(c,new tn(l,_))}return s}function on(r,e){return r.channels===e.channels}const dt=8;class ht{autoUpdateOutputBuffer=!0;_label;_device;_outputBuffers={};_pipeline;_bindGroups=[];_needsUpdatePipeline=!0;_needsResizeBuffer=!0;_inputs=[];_outputs=[];_uniforms=[];_uniformBuffers={};_width=10;_height=10;_execWidth;_execHeight;_csCode="";_csMain;_csDefine;_groupOffsets={inputs:0,uniforms:1,outputs:2};constructor(e,t,i){this._label=e,this._device=t,this._csMain=i.csMain,this._csDefine=i.csDefine,this._inputs=i.inputs,this._outputs=i.outputs,this._uniforms=i.uniforms,this.autoUpdateOutputBuffer=i.autoUpdateOutputBuffer??!0,i.uniforms.forEach(n=>{this._uniformBuffers[n.label]=t.createBuffer({label:this._label,size:n.data.byteLength,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this._device.queue.writeBuffer(this._uniformBuffers[n.label],0,n.data)})}setCSCode({csDefine:e,csMain:t}){this._csDefine=e,this._csMain=t,this._needsUpdatePipeline=!0}setSize(e,t){e=Math.ceil(e),t=Math.ceil(t);const i=e!==this._width||t!==this._height;this._width=e,this._height=t,i&&(this._needsResizeBuffer=!0,this._needsUpdatePipeline=!0)}setExecuteSize(e,t){e=Math.ceil(e),t=Math.ceil(t),this._execWidth=e,this._execHeight=t}setOutputParams(e){this.autoUpdateOutputBuffer&&this._updateOutputBuffers(e),this._needsUpdatePipeline=!0}setOutputBuffers(e){this._outputBuffers=Object.keys(e).reduce((t,i)=>(t[i]={buffer:e[i],params:{channels:4}},t),{})}setUniform(e,t){const i=this._uniformBuffers[e];this._device.queue.writeBuffer(i,0,t)}getOutput(e){return this._needsResizeBuffer&&this.autoUpdateOutputBuffer&&(this._resizeOutputBuffers(),this._needsResizeBuffer=!1),this._outputBuffers[e].buffer}dispose(e=!0){Object.keys(this._uniformBuffers).forEach(t=>{this._uniformBuffers[t].destroy()}),e&&Object.keys(this._outputBuffers).forEach(t=>{this._outputBuffers[t].buffer.destroy()})}_createBuffer(e){const t=this._width*this._height*4*4;return this._device.createBuffer({label:this._label,size:Math.max(t,80),usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST|GPUBufferUsage.COPY_SRC})}_resizeOutputBuffers(){const e=this._outputBuffers;for(const t in e){const{buffer:i,params:n}=e[t];i.destroy(),e[t].buffer=this._createBuffer(n)}}_updateOutputBuffers(e){const t=this._outputBuffers;for(const i in e){const n=e[i];if(!on(n,t[i]?.params||{})){t[i]?.buffer.destroy();const o=this._createBuffer(n);t[i]={buffer:o,params:n}}}}_updatePipeline(e,t){if(!this._needsUpdatePipeline)return;this._needsUpdatePipeline=!1;const i=this._device,n=this._getFullCs(e,t);n!==this._csCode&&(this._csCode=n,this._pipeline=i.createComputePipeline({label:this._label,layout:"auto",compute:{module:i.createShaderModule({label:this._label,code:n}),entryPoint:"main"}}),this._updateBindGroups())}_getFullCs(e,t){const i=this._inputs,n=this._uniforms;let o=0;const a=this._groupOffsets={inputs:0,uniforms:0,outputs:0};return i.length>0&&o++,n.length>0&&(a.uniforms=o,o++),a.outputs=o,`
${i.sort().map((u,l)=>{const p=`@group(${a.inputs}) @binding(${l}) `,c=`in_${u}`;return t[u]==="texture"?`${p} var ${c}: texture_2d<f32>;`:`${p} var<storage, read> ${c}: array<vec${e[u].channels}f>;`}).join(`
`)}
${this._uniforms.map((u,l)=>`@group(${a.uniforms}) @binding(${l}) var<uniform> ${u.label}: ${u.type};`).join(`
`)}

${this._outputs.map((u,l)=>`@group(${a.outputs}) @binding(${l}) var<storage, read_write> out_${u}: array<vec${this._outputBuffers[u].params.channels}f>;`).join(`
`)}
${this._csDefine??""}
@compute @workgroup_size(${dt}, ${dt}, 1)
fn main(@builtin(global_invocation_id) globalId: vec3u) {
${this._csMain}
}
`}_updateBindGroups(){const e=[],t=this._device,i=this._groupOffsets;this._uniforms.length>0&&(e[i.uniforms]=t.createBindGroup({label:this._label,layout:this._pipeline.getBindGroupLayout(i.uniforms),entries:this._uniforms.map((n,o)=>({binding:o,resource:{buffer:this._uniformBuffers[n.label]}}))})),this._bindGroups=e}createPass(e,t){this._needsResizeBuffer&&this.autoUpdateOutputBuffer&&(this._resizeOutputBuffers(),this._needsResizeBuffer=!1);const i=this._inputs.reduce((a,s)=>(a[s]=t[s].buffer?"buffer":"texture",a),{});this._updatePipeline(t,i);const n=this._groupOffsets;this._inputs.length>0&&(this._bindGroups[n.inputs]=this._device.createBindGroup({label:this._label,layout:this._pipeline.getBindGroupLayout(n.inputs),entries:this._inputs.map((a,s)=>({binding:s,resource:t[a].buffer?{buffer:t[a].buffer}:t[a].texture.createView()}))})),this._bindGroups[n.outputs]=this._device.createBindGroup({label:this._label,layout:this._pipeline.getBindGroupLayout(n.outputs),entries:this._outputs.map((a,s)=>({binding:s,resource:{buffer:this._outputBuffers[a].buffer}}))});const o=e.beginComputePass();o.setPipeline(this._pipeline),this._bindGroups.forEach((a,s)=>{o.setBindGroup(s,a)}),o.dispatchWorkgroups(Math.ceil((this._execWidth??this._width)/dt),Math.ceil((this._execHeight??this._height)/dt),1),o.end()}}const rt=34028234663852886e22;function nt(r,e,t){return Number.isNaN(r)?0:Math.min(Math.max(r,e),t)}const wi=`
const FLT_MAX = 3.4028234663852886e38;
fn sanitize(v: vec3f, lo: f32, hi: f32) -> vec3f {
  let bits = bitcast<vec3u>(v);
  let magnitude = bits & vec3u(0x7fffffffu);
  let negative = (bits & vec3u(0x80000000u)) != vec3u(0u);
  let infinite = select(vec3f(hi), vec3f(lo), negative);
  let clamped = select(clamp(v, vec3f(lo), vec3f(hi)), infinite, magnitude == vec3u(0x7f800000u));
  return select(clamped, vec3f(0.0), magnitude > vec3u(0x7f800000u));
}
`,ei=1412.83765,ti=1.64593172,ii=.431384981,ri=-.00294139609,ni=.192653254,oi=.00626026094,ai=.998620152,tr=15794576e-13,ir=.0322087631,rr=.00223151711,nr=.370974749,or=65504,ar=lr(or),ur=1/ar,sr=ar,Ct=Math.log(or+1),cr=1/Ct;function lr(r){return r<=tr?ei*r:r<=ir?ti*Math.pow(r,ii)+ri:ni*Math.log(r+oi)+ai}function an(r){return r<=rr?r/ei:r<=nr?Math.pow((r-ri)/ti,1/ii):Math.exp((r-ai)/ni)-oi}function un(r,e){return e==="log"?Math.log(r+1)*cr:lr(r)*ur}function sn(r,e){return e==="log"?Math.exp(r*Ct)-1:an(r*sr)}function cn({data:r,channels:e,inputScale:t,transfer:i="pu"}){const n=new Float32Array(r);for(let o=0;o<n.length;o+=e)for(let a=0;a<3;a++)n[o+a]=un(nt(n[o+a]*t,0,rt),i);return n}function ln({data:r,channels:e,inputScale:t,transfer:i="pu"}){const n=new Float32Array(r),o=1/t;for(let a=0;a<n.length;a+=e)for(let s=0;s<3;s++)n[a+s]=sn(nt(n[a+s],0,rt),i)*o;return n}function pn({data:r,channels:e}){let t=0;for(let a=0;a<r.length;a+=e){const s=nt(r[a],0,rt),u=nt(r[a+1],0,rt),l=nt(r[a+2],0,rt),p=.212671*s+.71516*u+.072169*l;t+=Math.log2(p+1e-4)}const i=r.length/e,n=t/i;return .18/Math.pow(2,n)}const pr=`
const a = ${ei};
const b = ${ti};
const c = ${ii};
const d = ${ri};
const e = ${ni};
const f = ${oi};
const g = ${ai};
const y0 =${tr};
const y1 =${ir};
const x0 =${rr};
const x1 =${nr};

const normScale = ${ur};
const rcpNormScale = ${sr};
`;function dn(r){return`
${pr}
const logXMax = ${Ct};
const logNormScale = ${cr};
${r==="log"?"fn HDRForward(y: f32) -> f32 { return log(y + 1.0) * logNormScale; }":`fn HDRForward(y: f32) -> f32 {
  if (y <= y0) { return a * y * normScale; }
  else if (y <= y1) { return (b * pow(y, c) + d) * normScale; }
  else { return (e * log(y + f) + g) * normScale; }
}`}`}function hn(r){return`
${pr}
const logXMax = ${Ct};
${r==="log"?"fn HDRInverse(x: f32) -> f32 { return exp(x * logXMax) - 1.0; }":`fn HDRInverse(x: f32) -> f32 {
  let y = x * rcpNormScale;
  if (y <= x0) { return y / a; }
  else if (y <= x1) { return pow((y - d) / b, 1 / c); }
  else { return exp((y - g) / e) - f; }
}`}
`}class Ut{x;y;width;height;constructor(e,t,i,n){this.x=e,this.y=t,this.width=i,this.height=n}}class fn{_device;_isHDR;_hdrTransfer;_inputPassAux;_inputPassColor;_outputPass;_copyPass;_isInputTexture;constructor(e,t,i="pu"){this._device=e,this._isHDR=t,this._hdrTransfer=i;const n=[{label:"inputScale",type:"f32",data:new Float32Array([1])},{label:"inputSize",type:"vec2i",data:new Int32Array(2)},{label:"outputSize",type:"vec2i",data:new Int32Array(2)},{label:"inputOffset",type:"vec2i",data:new Int32Array(2)}];this._inputPassAux=new ht("inputPassAux",this._device,{inputs:["color","albedo","normal"],outputs:["color","albedo","normal"],uniforms:n,csDefine:"",csMain:""}),this._inputPassColor=new ht("inputPassColor",this._device,{inputs:["color"],outputs:["color"],uniforms:n,csDefine:"",csMain:""}),this._outputPass=new ht("outputPass",this._device,{inputs:["color","raw"],outputs:["color"],uniforms:[{label:"inputScale",type:"f32",data:new Float32Array([1])},{label:"inputSize",type:"vec2i",data:new Int32Array(2)},{label:"outputSize",type:"vec2i",data:new Int32Array(2)},{label:"imageSize",type:"vec2i",data:new Int32Array(2)},{label:"inputOffset",type:"vec2i",data:new Int32Array(2)},{label:"outputOffset",type:"vec2i",data:new Int32Array(2)}],csDefine:"",csMain:""}),this._copyPass=new ht("copyPass",this._device,{inputs:["color"],outputs:["color"],autoUpdateOutputBuffer:!1,uniforms:[{label:"size",type:"vec2i",data:new Int32Array(2)}],csMain:`
let outIdx = i32(globalId.x + globalId.y * u32(size.x));
out_color[outIdx] = textureLoad(in_color, globalId.xy, 0);
`}),this._inputPassAux.setOutputParams({color:{channels:3},albedo:{channels:3},normal:{channels:3}}),this._inputPassColor.setOutputParams({color:{channels:3}}),this._outputPass.setOutputParams({color:{channels:4}})}_updatePasses(e,t=!1){if(this._isInputTexture!=null&&this._isInputTexture===e)return;this._isInputTexture=e;const i=this._isHDR,n=dn(this._hdrTransfer)+wi;function o(s){return e?`textureLoad(in_${s}, vec2u(inputPosition), 0)`:`in_${s}[inIdx]`}const a=`
let x = i32(globalId.x);
let y = i32(globalId.y);
let inputPosition = clamp(
  vec2i(x, y) + inputOffset,
  vec2i(0),
  inputSize - vec2i(1)
);
let inIdx = inputPosition.y * inputSize.x + inputPosition.x;
let col = ${o("color")};

let outIdx = y * outputSize.x + x;

if (${t}) {
  // Denoise the inversed alpha. Or the anti aliased edge will be too dark after denoised
  out_color[outIdx] = sanitize(vec3f(1.0 - col.a), 0.0, 1.0);
}
else if (${i}) {
  let scaled = sanitize(col.rgb * inputScale, 0.0, FLT_MAX);
  out_color[outIdx] = vec3f(HDRForward(scaled.r), HDRForward(scaled.g), HDRForward(scaled.b));
}
else {
  out_color[outIdx] = sanitize(col.rgb, 0.0, 1.0);
}
`;this._inputPassAux.setCSCode({csDefine:n,csMain:`
${a}
let alb = ${o("albedo")};
let nor = ${o("normal")};
// Normals arrive [0, 1]-encoded, so OIDN's [-1, 1] clamp becomes [0, 1].
out_normal[outIdx] = sanitize(nor.rgb, 0.0, 1.0);
out_albedo[outIdx] = sanitize(alb.rgb, 0.0, 1.0);
  `}),this._inputPassColor.setCSCode({csDefine:n,csMain:`
${a}
`}),this._outputPass.setCSCode({csDefine:hn(this._hdrTransfer)+wi,csMain:`
let x = i32(globalId.x);
let y = i32(globalId.y);
if (x >= outputSize.x || y >= outputSize.y) {
  return;
}
let inIdx = (y + inputOffset.y) * inputSize.x + x + inputOffset.x;
let outIdx = (y + outputOffset.y) * imageSize.x + x + outputOffset.x;
let col = in_color[inIdx];
let raw = ${e?"textureLoad(in_raw, globalId.xy + vec2u(outputOffset), 0)":"in_raw[outIdx]"};

// The network output may contain negative values or NaNs.
let denoised = sanitize(col.rgb, 0.0, ${i&&!t?"FLT_MAX":"1.0"});
if (${t}) {
  out_color[outIdx] = vec4f(raw.rgb, 1.0 - denoised.r);
}
else if (${i}) {
  out_color[outIdx] = vec4f(
    vec3f(HDRInverse(denoised.r), HDRInverse(denoised.g), HDRInverse(denoised.b)) / inputScale,
    // Pick the alpha
    raw.a
  );
}
else {
  out_color[outIdx] = vec4f(denoised, raw.a);
}
`})}setImageSize(e,t){this._inputPassAux.setUniform("inputSize",new Int32Array([e,t])),this._inputPassColor.setUniform("inputSize",new Int32Array([e,t])),this._outputPass.setUniform("imageSize",new Int32Array([e,t])),this._outputPass.setSize(e,t),this._copyPass.setSize(e,t),this._copyPass.setUniform("size",new Int32Array([e,t]))}setInputTile(e){const t=new Int32Array([e.width,e.height]);[this._inputPassAux,this._inputPassColor].forEach(i=>{i.setUniform("inputOffset",new Int32Array([e.x,e.y])),i.setUniform("outputSize",t),i.setSize(t[0],t[1])}),this._outputPass.setUniform("inputSize",t)}setOutputTile(e,t){const i=this._outputPass,n=new Int32Array([e.width,e.height]),o=e.x-t.x,a=e.y-t.y;i.setUniform("outputSize",n),i.setUniform("inputOffset",new Int32Array([o,a])),i.setUniform("outputOffset",new Int32Array([e.x,e.y])),i.setExecuteSize(n[0],n[1])}forward(e,t,i,n){const o=e instanceof GPUTexture;this._updatePasses(o,n);const a=this._inputPassAux,s=this._inputPassColor,u=this._device.createCommandEncoder();function l(p){return p instanceof GPUTexture?{texture:p,channels:4}:{buffer:p,channels:4}}return t&&i?a.createPass(u,{color:l(e),albedo:l(t),normal:l(i)}):s.createPass(u,{color:l(e)}),this._device.queue.submit([u.finish()]),t&&i?{color:a.getOutput("color"),albedo:a.getOutput("albedo"),normal:a.getOutput("normal")}:{color:s.getOutput("color")}}inverse(e,t){const n=this._device.createCommandEncoder(),o=this._outputPass;return o.createPass(n,{color:{buffer:e,channels:4},raw:t instanceof GPUBuffer?{buffer:t,channels:4}:{texture:t,channels:4}}),this._device.queue.submit([n.finish()]),o.getOutput("color")}copyInputDataToOutput(e){const t=this._device.createCommandEncoder(),n=this._outputPass.getOutput("color"),o=this._copyPass;e instanceof GPUTexture?(o.setOutputBuffers({color:n}),o.createPass(t,{color:{texture:e,channels:4}})):t.copyBufferToBuffer(e,0,n,0,n.size),this._device.queue.submit([t.finish()])}dispose(){this._outputPass.dispose(),this._inputPassAux.dispose(),this._inputPassColor.dispose(),this._copyPass.dispose(!1)}}const gn=256,mn=432,$n=16,_n=16,Z=16;function Re(r,e){return Math.ceil(r/e)*e}function dr(r,e){return Math.floor(r/e)*e}function xi(r,e,t){const i=Math.round(t*r/e),n=Math.round((t+1)*r/e);return{start:i,end:n}}function ft(r,e,t,i=0){const n=e-r,o=Math.max(i,Re(n,Z));let a=r-Math.floor((o-n)/2);return a=xt(a,0,Math.max(0,t-o)),{start:a,end:a+o}}function vi(r,e,t,i){if(!Number.isInteger(r)||r<=0||!Number.isInteger(e)||e<=0)throw new Error("Tile grid dimensions must be positive integers");if(!Number.isFinite(t)||t<=0)throw new Error("Maximum tile size must be positive");if(!Number.isFinite(i)||i<0)throw new Error("Tile overlap must be non-negative");const n=Math.max(Z,dr(t,Z)),o=Re(i,Z),a=Math.max(1,Math.ceil(r/n)),s=Math.max(1,Math.ceil(e/n)),u=[];let l=0,p=0;for(let g=0;g<s;g++){const h=xi(e,s,g);for(let _=0;_<a;_++){const $=xi(r,a,_),w={start:_===0?$.start:Math.max(0,$.start-o),end:_===a-1?$.end:Math.min(r,$.end+o)},y={start:g===0?h.start:Math.max(0,h.start-o),end:g===s-1?h.end:Math.min(e,h.end+o)},b=ft(w.start,w.end,r),m=ft(y.start,y.end,e),v={x:$.start,y:h.start,width:$.end-$.start,height:h.end-h.start},x={x:b.start,y:m.start,width:b.end-b.start,height:m.end-m.start};l=Math.max(l,v.width),p=Math.max(p,v.height),u.push({column:_,row:g,input:x,output:v})}}const c=()=>new Set(u.map(({input:g})=>`${g.width}x${g.height}`));if(c().size>2){const g=Math.max(...u.map(({input:w})=>w.width)),h=Math.max(...u.map(({input:w})=>w.height)),_=u.reduce((w,{input:y})=>w+g*y.height,0),$=u.reduce((w,{input:y})=>w+y.width*h,0);if(_<=$)for(const w of u){const y=ft(w.input.x,w.input.x+w.input.width,r,g);w.input.x=y.start,w.input.width=y.end-y.start}else for(const w of u){const y=ft(w.input.y,w.input.y+w.input.height,e,h);w.input.y=y.start,w.input.height=y.end-y.start}}const d=c(),f=u.reduce((g,{input:h})=>g+h.width*h.height,0);return{columns:a,rows:s,overlap:o,maxOutputWidth:l,maxOutputHeight:p,inputPixelCount:f,inputShapeCount:d.size,tiles:u}}function xt(r,e,t){return Math.min(Math.max(r,e),t)}function yn(r,e){const t=[...r].sort((i,n)=>i-n);return t[Math.ceil(t.length*e)-1]}class wn{enabled;maxTileSize;minTileSize;targetTileTimeMs;_tileSize;_adjustmentStep;_smoothedTileTimeMs;_completeExecutionsSinceChange=0;constructor(e,t=!0){const i=typeof t=="object"?t:{};this.enabled=t!==!1,this.maxTileSize=Math.max(Z,dr(e,Z)),this.minTileSize=xt(Re(i.minTileSize??gn,Z),Z,this.maxTileSize),this.targetTileTimeMs=Math.max(1,i.targetTileTimeMs??$n),this._adjustmentStep=Math.max(Z,Re(i.adjustmentStep??_n,Z)),this._tileSize=this.enabled?xt(Re(i.initialTileSize??mn,Z),this.minTileSize,this.maxTileSize):this.maxTileSize}get tileSize(){return this._tileSize}observe(e){if(!this.enabled||e.length===0)return!1;const t=e.filter(a=>Number.isFinite(a)&&a>=0);if(t.length===0)return!1;const i=t.length>=3?t.slice(1):t,n=yn(i,.75);if(this._smoothedTileTimeMs=this._smoothedTileTimeMs===void 0?n:this._smoothedTileTimeMs*.65+n*.35,this._completeExecutionsSinceChange++,this._completeExecutionsSinceChange<2)return!1;let o=this._tileSize;return this._smoothedTileTimeMs>this.targetTileTimeMs*1.25?o-=this._adjustmentStep:this._smoothedTileTimeMs<this.targetTileTimeMs*.65&&(o+=this._adjustmentStep),o=xt(Re(o,Z),this.minTileSize,this.maxTileSize),o===this._tileSize?!1:(this._tileSize=o,this._smoothedTileTimeMs=void 0,this._completeExecutionsSinceChange=0,!0)}}function S(r,e){return{op:"conv2d",id:r,input:e,weight:`${r}.weight`,bias:`${r}.bias`,activation:"relu",padding:"same"}}function Te(r,e){return{op:"maxPool2d",id:r,input:e,size:2,stride:2,padding:"same"}}function Ie(r,e){return{op:"upsample2d",id:r,input:e,scale:2,mode:"nearest"}}function Be(r,e,t){return{op:"concat",id:r,inputs:[e,t],axis:"channels"}}const xn={schemaVersion:1,id:"oidn-unet-small-v1",family:"oidn-unet-small",input:"input",output:"dec_conv0",receptiveField:174,nodes:[S("enc_conv0","input"),S("enc_conv1","enc_conv0"),Te("pool1","enc_conv1"),S("enc_conv2","pool1"),Te("pool2","enc_conv2"),S("enc_conv3","pool2"),Te("pool3","enc_conv3"),S("enc_conv4","pool3"),Te("pool4","enc_conv4"),S("enc_conv5a","pool4"),S("enc_conv5b","enc_conv5a"),Ie("up4","enc_conv5b"),Be("concat4","up4","pool3"),S("dec_conv4a","concat4"),S("dec_conv4b","dec_conv4a"),Ie("up3","dec_conv4b"),Be("concat3","up3","pool2"),S("dec_conv3a","concat3"),S("dec_conv3b","dec_conv3a"),Ie("up2","dec_conv3b"),Be("concat2","up2","pool1"),S("dec_conv2a","concat2"),S("dec_conv2b","dec_conv2a"),Ie("up1","dec_conv2b"),Be("concat1","up1","input"),S("dec_conv1a","concat1"),S("dec_conv1b","dec_conv1a"),S("dec_conv0","dec_conv1b")]},vn={schemaVersion:1,id:"oidn-unet-large-v1",family:"oidn-unet-large",input:"input",output:"dec_conv1c",receptiveField:202,nodes:[S("enc_conv1a","input"),S("enc_conv1b","enc_conv1a"),Te("pool1","enc_conv1b"),S("enc_conv2a","pool1"),S("enc_conv2b","enc_conv2a"),Te("pool2","enc_conv2b"),S("enc_conv3a","pool2"),S("enc_conv3b","enc_conv3a"),Te("pool3","enc_conv3b"),S("enc_conv4a","pool3"),S("enc_conv4b","enc_conv4a"),Te("pool4","enc_conv4b"),S("enc_conv5a","pool4"),S("enc_conv5b","enc_conv5a"),Ie("up4","enc_conv5b"),Be("concat4","up4","pool3"),S("dec_conv4a","concat4"),S("dec_conv4b","dec_conv4a"),Ie("up3","dec_conv4b"),Be("concat3","up3","pool2"),S("dec_conv3a","concat3"),S("dec_conv3b","dec_conv3a"),Ie("up2","dec_conv3b"),Be("concat2","up2","pool1"),S("dec_conv2a","concat2"),S("dec_conv2b","dec_conv2a"),Ie("up1","dec_conv2b"),Be("concat1","up1","input"),S("dec_conv1a","concat1"),S("dec_conv1b","dec_conv1a"),S("dec_conv1c","dec_conv1b")]},bn=[xn,vn];function hr(r){const e=new Set;for(const t of r.nodes)t.op==="conv2d"&&(e.add(t.weight),e.add(t.bias));return e}function bi(r){return r.desc.getByteSize()}function fr(r){return[...r].sort().join(", ")}function gr(r,e=bn){const t=e.filter(i=>{const n=hr(i);return[...n].some(o=>!r.has(o))?!1:i.allowAdditionalTensors===!0||[...r.keys()].every(o=>n.has(o))});if(t.length===1)return t[0];throw t.length>1?new Error(`Ambiguous OIDN model topology: ${t.map(i=>i.id).join(", ")}`):new Error(`Unsupported OIDN model topology. TZA tensors: ${fr([...r.keys()])}`)}function ki(r,e,t){const i=r.get(e);if(!i)throw new Error(`Model ${t} is missing tensor ${e}`);if(i.data.byteLength!==bi(i))throw new Error(`Tensor ${e} has ${i.data.byteLength} bytes, expected ${bi(i)}`);return i}function kn(r,e=gr(r)){if(e.schemaVersion!==1)throw new Error(`Unsupported model descriptor schema ${e.schemaVersion}`);const t=hr(e);if(!e.allowAdditionalTensors){const c=[...r.keys()].filter(d=>!t.has(d));if(c.length>0)throw new Error(`Model ${e.id} has unexpected tensors: ${fr(c)}`)}const i=new Map,n=new Map,o=new Map,a=new Set([e.input]);let s,u;const l=(c,d)=>{const f=i.get(c);if(f===void 0)throw new Error(`Model ${e.id} node ${d} reads unknown or forward value ${c}`);return f};for(const c of e.nodes){if(a.has(c.id))throw new Error(`Model ${e.id} produces duplicate value ${c.id}`);if(c.op==="conv2d"){const d=ki(r,c.weight,e.id),f=ki(r,c.bias,e.id),g=d.desc.dims;if(d.desc.layout!=="oihw"||g.length!==4)throw new Error(`Tensor ${c.weight} must use OIHW layout`);if(g[2]!==3||g[3]!==3)throw new Error(`Tensor ${c.weight} must use a 3x3 kernel`);if(f.desc.layout!=="x"||f.desc.dims.length!==1)throw new Error(`Tensor ${c.bias} must be a one-dimensional bias`);if(f.desc.dims[0]!==g[0])throw new Error(`Tensor ${c.bias} has ${f.desc.dims[0]} channels, expected ${g[0]}`);if(d.desc.dataType!==f.desc.dataType)throw new Error(`Weight and bias dtype differ for ${c.id}`);if(u&&u!==d.desc.dataType)throw new Error(`Mixed tensor dtypes are not supported by model ${e.id}`);u=d.desc.dataType,c.input===e.input&&s===void 0&&(s=g[1],i.set(e.input,s));const h=l(c.input,c.id);if(h!==g[1])throw new Error(`Tensor ${c.weight} expects ${g[1]} input channels, but ${c.input} provides ${h}`);i.set(c.id,g[0]),n.set(c.id,{weight:d,bias:f,inputChannels:g[1],outputChannels:g[0],kernelHeight:g[2],kernelWidth:g[3]}),o.set(c.id,{inputChannels:g[1],outputChannels:g[0]})}else if(c.op==="concat"){if(c.inputs.length<2)throw new Error(`Concat ${c.id} requires at least two inputs`);const d=c.inputs.reduce((f,g)=>f+l(g,c.id),0);i.set(c.id,d)}else i.set(c.id,l(c.input,c.id));a.add(c.id)}if(s===void 0||u===void 0)throw new Error(`Model ${e.id} has no convolution reading its input`);const p=i.get(e.output);if(p===void 0)throw new Error(`Model ${e.id} output ${e.output} is not produced`);if(p!==3)throw new Error(`Model ${e.id} must produce 3 channels, got ${p}`);return{spec:e,inputChannels:s,outputChannels:p,tensorDataType:u,channelsByValue:i,convChannels:o,convTensors:n}}function Tn(r){return r.op==="concat"?r.inputs:[r.input]}function In(r){const e=new Map;for(const t of r.nodes)for(const i of Tn(t)){const n=e.get(i)??[];n.push(t),e.set(i,n)}return e}function Wt(r,e,t){const i=r.get(e);if(!(i===void 0||i.length!==1||i[0].op!==t))return i[0]}function ui(r,e={}){const t=r.spec,i=In(t),n=new Map(t.nodes.map(p=>[p.id,p])),o=new Set,a=new Map;let s=0,u=0;if(e.fuseConvPool!==!1)for(const p of t.nodes){if(p.op!=="conv2d"||p.activation!=="relu")continue;const c=Wt(i,p.id,"maxPool2d");!c||c.op!=="maxPool2d"||c.size!==2||c.stride!==2||(o.add(p.id),a.set(c.id,{op:"fusedConvReluMaxPool2d",id:c.id,input:p.input,conv:p,pool:c}),s++)}if(e.fuseUpsampleConcatConv!==!1)for(const p of t.nodes){if(p.op!=="conv2d")continue;const c=n.get(p.input);if(c?.op!=="concat"||c.inputs.length!==2||Wt(i,c.id,"conv2d")?.id!==p.id)continue;const d=r.channelsByValue.get(c.inputs[0]);if(d===void 0||d%4!==0)continue;const f=c.inputs.map(h=>{const _=n.get(h);return _?.op==="upsample2d"&&_.scale===2&&_.mode==="nearest"&&Wt(i,_.id,"concat")?.id===c.id?{value:_.input,upsample:_}:{value:h}});if(f.filter(h=>h.upsample).length===1){o.add(c.id);for(const h of c.inputs){const _=n.get(h);_?.op==="upsample2d"&&o.add(_.id)}a.set(p.id,{op:"fusedUpsampleConcatConv2d",id:p.id,inputs:f,conv:p}),u++}}const l=[];for(const p of t.nodes){const c=a.get(p.id);c?l.push(c):o.has(p.id)||l.push(p)}return{spec:t,nodes:l,fusions:{convPool:s,upsampleConcatConv:u}}}function Bn(r){return r.op==="concat"?r.inputs:r.op==="fusedUpsampleConcatConv2d"?r.inputs.map(e=>e.value):[r.input]}function Ti(r,e){return r.width===e.width&&r.height===e.height}function Pn(r,e,t,i){if(!Number.isInteger(e)||e<=0||!Number.isInteger(t)||t<=0)throw new Error(`Invalid model input size ${e}x${t}`);const n=ui(r,i),o={width:e,height:t,channels:r.inputChannels},a=new Map([[r.spec.input,o]]),s=[],u=(c,d)=>{const f=a.get(c);if(!f)throw new Error(`Planned node ${d} reads missing value ${c}`);return f};for(const c of n.nodes){let d;if(c.op==="conv2d"){const f=u(c.input,c.id);d={width:f.width,height:f.height,channels:r.convChannels.get(c.id).outputChannels}}else if(c.op==="maxPool2d"){const f=u(c.input,c.id);d={width:Math.ceil(f.width/2),height:Math.ceil(f.height/2),channels:f.channels}}else if(c.op==="upsample2d"){const f=u(c.input,c.id);d={width:f.width*2,height:f.height*2,channels:f.channels}}else if(c.op==="concat"){const f=c.inputs.map(g=>u(g,c.id));if(f.some(g=>!Ti(g,f[0])))throw new Error(`Concat ${c.id} has mismatched spatial shapes`);d={width:f[0].width,height:f[0].height,channels:f.reduce((g,h)=>g+h.channels,0)}}else if(c.op==="fusedConvReluMaxPool2d"){const f=u(c.input,c.id);d={width:Math.ceil(f.width/2),height:Math.ceil(f.height/2),channels:r.convChannels.get(c.conv.id).outputChannels}}else{const f=c.inputs.map(g=>{const h=u(g.value,c.id);return g.upsample?{...h,width:h.width*2,height:h.height*2}:h});if(f.some(g=>!Ti(g,f[0])))throw new Error(`Fused decoder ${c.id} has mismatched spatial shapes`);d={width:f[0].width,height:f[0].height,channels:r.convChannels.get(c.conv.id).outputChannels}}a.set(c.id,d),s.push(d)}const l=new Map;n.nodes.forEach((c,d)=>{for(const f of Bn(c))l.set(f,d)}),l.set(r.spec.output,n.nodes.length);const p=n.nodes.map((c,d)=>({node:c,outputShape:s[d],lastUse:l.get(c.id)??d}));return{...n,inputShape:o,valueShapes:a,plannedNodes:p}}const re={MAP_READ:1,MAP_WRITE:2,COPY_SRC:4,COPY_DST:8,INDEX:16,VERTEX:32,UNIFORM:64,STORAGE:128,INDIRECT:256,QUERY_RESOLVE:512},Ii={READ:1,WRITE:2},$e=8,Ae=$e+2,mr=3*3;function Bi(r,e,t=!1){const i=r==="fp16"?2:4,n=Ae*Ae*e,o=t?mr*e*4:0;return(n+o)*4*i}function Sn(r){return r==="fp16"?"vec4<f16>":"vec4<f32>"}function Cn(r){return r==="fp16"?`enable f16;
`:""}function En(r,e,t){const i=n=>`${t}[weightBase + ${n}u]`;return r==="fp16"?`
        let inputValue = vec4<f16>(${e});
        var partial = vec4<f16>(0.0h);
        partial = fma(${i(0)}, vec4<f16>(inputValue.x), partial);
        partial = fma(${i(1)}, vec4<f16>(inputValue.y), partial);
        partial = fma(${i(2)}, vec4<f16>(inputValue.z), partial);
        partial = fma(${i(3)}, vec4<f16>(inputValue.w), partial);
        acc += vec4<f32>(partial);
`:`
        let inputValue = vec4<f32>(${e});
        acc = fma(vec4<f32>(${i(0)}), vec4<f32>(inputValue.x), acc);
        acc = fma(vec4<f32>(${i(1)}), vec4<f32>(inputValue.y), acc);
        acc = fma(vec4<f32>(${i(2)}), vec4<f32>(inputValue.z), acc);
        acc = fma(vec4<f32>(${i(3)}), vec4<f32>(inputValue.w), acc);
`}function Mn(r,e,t,i=!1){if(!Number.isInteger(t)||t<1)throw new Error(`Final RGB shader requires positive input blocks, got ${t}`);const n=Sn(r),o="vec4<f32>",a=Ae*Ae*t,s=mr*t*4,u=e==="relu"?"max(acc, vec4<f32>(0.0))":"acc",l=En(r,"inputTile[patchBase + inputBlock]",i?"weightTile":"weights");return`${Cn(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}

@group(0) @binding(0) var<storage, read> inputData: array<${n}>;
@group(0) @binding(1) var<storage, read> weights: array<${n}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${o}>;
@group(0) @binding(4) var<uniform> params: Params;

var<workgroup> inputTile: array<${n}, ${a}>;
${i?`var<workgroup> weightTile: array<${n}, ${s}>;`:""}

@compute @workgroup_size(${$e}, ${$e}, 1)
fn main(
  @builtin(local_invocation_id) localId: vec3<u32>,
  @builtin(global_invocation_id) gid: vec3<u32>,
  @builtin(workgroup_id) workgroupId: vec3<u32>
) {
  let localLinear = localId.y * ${$e}u + localId.x;
  for (
    var loadIndex = localLinear;
    loadIndex < ${a}u;
    loadIndex += ${$e*$e}u
  ) {
    let tilePixel = loadIndex / ${t}u;
    let inputBlock = loadIndex % ${t}u;
    let tileX = tilePixel % ${Ae}u;
    let tileY = tilePixel / ${Ae}u;
    let inputX = i32(workgroupId.x * ${$e}u + tileX) - 1;
    let inputY = i32(workgroupId.y * ${$e}u + tileY) - 1;
    var value = ${n}(0.0);
    if (
      inputX >= 0 && inputX < i32(params.inputWidth) &&
      inputY >= 0 && inputY < i32(params.inputHeight)
    ) {
      let inputIndex =
        (u32(inputY) * params.inputWidth + u32(inputX)) *
        ${t}u + inputBlock;
      value = inputData[inputIndex];
    }
    inputTile[loadIndex] = value;
  }

${i?`  for (
    var loadIndex = localLinear;
    loadIndex < ${s}u;
    loadIndex += ${$e*$e}u
  ) {
    weightTile[loadIndex] = weights[loadIndex];
  }

`:""}  // Out-of-range invocations must reach this barrier before returning.
  workgroupBarrier();

  let outputInBounds =
    gid.x < params.outputWidth &&
    gid.y < params.outputHeight &&
    gid.z < params.outputBlocks;
  if (!outputInBounds) {
    return;
  }

  var acc = bias[gid.z];
  for (var ky = 0u; ky < 3u; ky++) {
    let inputY = i32(gid.y) + i32(ky) - 1;
    if (inputY < 0 || inputY >= i32(params.inputHeight)) {
      continue;
    }
    for (var kx = 0u; kx < 3u; kx++) {
      let inputX = i32(gid.x) + i32(kx) - 1;
      if (inputX < 0 || inputX >= i32(params.inputWidth)) {
        continue;
      }
      let patchBase =
        ((localId.y + ky) * ${Ae}u + localId.x + kx) *
        ${t}u;
      for (var inputBlock = 0u; inputBlock < ${t}u; inputBlock++) {
        let weightBase =
          ((ky * 3u + kx) * ${t}u + inputBlock) * 4u;
        ${l}
      }
    }
  }

  let outputIndex =
    (gid.y * params.outputWidth + gid.x) * 1u + gid.z;
  outputData[outputIndex] = ${u};
}
`}class $r{_stats=new Map;track(e,t){let i=this._stats.get(e);return i||(i={created:0,destroyed:0,live:0,peakLive:0,resources:new Set},this._stats.set(e,i)),i.resources.has(t)||(i.resources.add(t),i.created++,i.live++,i.peakLive=Math.max(i.peakLive,i.live)),t}release(e,t,i){if(!t)return!1;const n=this._stats.get(e);if(!n?.resources.delete(t))return!1;try{i()}finally{n.destroyed++,n.live--}return!0}snapshot(e=0){let t=0,i=0,n=0,o=0;const a={};for(const[s,u]of this._stats){const l={created:u.created,destroyed:u.destroyed,live:u.live,peakLive:u.peakLive};a[s]=l,t+=l.live,i+=l.created,n+=l.destroyed,o+=l.peakLive}return{live:t,created:i,destroyed:n,peakLive:o,pending:e,byKind:a}}}const Pi=new WeakMap;function An(r){let e=Pi.get(r);return e||(e=new Map,Pi.set(r,e)),e}const Q=8,_r=8,H=8,se=H+2;function ce(r){const[e,t]=r.workgroupSize;return{workgroupX:e,workgroupY:t,rowsPerThread:r.rowsPerThread,tileM:t*r.rowsPerThread,tileNBlocks:e,tileKBlocks:_r}}function ve(r){const e=ce(r),t=r.sharedLayout==="padded"||r.sharedLayout==="padded-input",i=r.sharedLayout==="padded"||r.sharedLayout==="padded-weights";return{input:e.tileM*e.tileKBlocks+(t?e.workgroupY:0),weights:e.tileKBlocks*e.tileNBlocks*(i?5:4)}}function Ke(r,e){return e.sharedLayout==="padded"||e.sharedLayout==="padded-input"?`(${r}) + (${r}) / ${e.rowsPerThread*_r}u`:r}function si(r,e){return e.sharedLayout==="padded"||e.sharedLayout==="padded-weights"?`(${r}) + (${r}) / 4u`:r}function ci(r,e){return Math.ceil(r/e)*e}function M(r){return Math.ceil(r/4)}function On(r,e){return r.width*r.height*M(r.channels)*4*e}let et;function yr(r){const e=r&32768?-1:1,t=r>>>10&31,i=r&1023;return t===0?e*i*2**-24:t===31?i===0?e*(1/0):NaN:e*(1+i/1024)*2**(t-15)}const Si=new DataView(new ArrayBuffer(4));function wr(r){Si.setFloat32(0,r);const e=Si.getUint32(0),t=e>>>16&32768,i=e>>>23&255,n=e&8388607;if(i===255)return t|31744|(n?512:0);const o=i-127+15;if(o>=31)return t|31744;if(o<=0){if(o<-10)return t;const u=n|8388608,l=14-o,p=u>>>l,c=u&(1<<l)-1,d=1<<l-1,f=c>d||c===d&&p&1?p+1:p;return t|f}const a=o<<10|n>>>13,s=n&8191;return t|(s>4096||s===4096&&a&1?a+1:a)}function Nn(){if(!et){et=new Float32Array(65536);for(let r=0;r<et.length;r++)et[r]=yr(r)}return et}function bt(r){if(r.desc.dataType==="Float32")return new Float32Array(r.data.buffer,r.data.byteOffset,r.data.byteLength/4);const e=new Uint16Array(r.data.buffer,r.data.byteOffset,r.data.byteLength/2),t=new Float32Array(e.length);if(e.length<4096)for(let i=0;i<e.length;i++)t[i]=yr(e[i]);else{const i=Nn();for(let n=0;n<e.length;n++)t[n]=i[e[n]]}return t}function st(r,e,t,i){const n=ci(t.byteLength,4),o=r.createBuffer({label:e,size:n,usage:i,mappedAtCreation:!0});return new Uint8Array(o.getMappedRange()).set(t),o.unmap(),o}function Ci(r,e,t){const i=new Uint32Array(ci(t.length,4));return i.set(t),st(r,e,new Uint8Array(i.buffer,i.byteOffset,i.byteLength),re.UNIFORM)}function zn(r,e,t,i,n){const o=M(t.inputChannels),a=M(t.outputChannels),s=a*t.kernelHeight*t.kernelWidth*o*4*4,u=i==="fp16"&&t.weight.desc.dataType==="Float16",l=i==="fp16"?new Uint16Array(s):void 0,p=l?void 0:new Float32Array(s),c=u?new Uint16Array(t.weight.data.buffer,t.weight.data.byteOffset,t.weight.data.byteLength/2):void 0,d=c?void 0:bt(t.weight);for(let h=0;h<a;h++)for(let _=0;_<t.kernelHeight;_++)for(let $=0;$<t.kernelWidth;$++)for(let w=0;w<o;w++)for(let y=0;y<4;y++){const b=h*4+y;for(let m=0;m<4;m++){const v=w*4+m,k=(n==="k-major"?(((_*t.kernelWidth+$)*o+w)*a+h)*16:(((h*t.kernelHeight+_)*t.kernelWidth+$)*o+w)*16)+m*4+y;if(b<t.outputChannels&&v<t.inputChannels){const B=((b*t.inputChannels+v)*t.kernelHeight+_)*t.kernelWidth+$;l?l[k]=c?c[B]:wr(d[B]):p[k]=d[B]}}}const f=new Float32Array(a*4);f.set(bt(t.bias));const g=st(r,`oidn/${e}/weights/${i}/${n}`,l?new Uint8Array(l.buffer):new Uint8Array(p.buffer),re.STORAGE);try{return{weights:g,weightLayout:n,bias:st(r,`oidn/${e}/bias`,new Uint8Array(f.buffer),re.STORAGE)}}catch(h){throw g.destroy(),h}}function L(r){return r==="fp16"?"vec4<f16>":"vec4<f32>"}function fe(r){return r==="fp16"?`enable f16;
`:""}function ae(r,e){return e==="fp16"?`vec4<f16>(${r})`:r}function le(r,e){return e==="relu"?`max(${r}, vec4<f32>(0.0))`:r}function ct(r,e,t){return t==="fp32"?`
let inputValue = vec4<f32>(${r});
let weightBase = ${e};
acc = fma(vec4<f32>(weights[weightBase]), vec4<f32>(inputValue.x), acc);
acc = fma(vec4<f32>(weights[weightBase + 1u]), vec4<f32>(inputValue.y), acc);
acc = fma(vec4<f32>(weights[weightBase + 2u]), vec4<f32>(inputValue.z), acc);
acc = fma(vec4<f32>(weights[weightBase + 3u]), vec4<f32>(inputValue.w), acc);
`:`
let inputValue = vec4<f16>(${r});
let weightBase = ${e};
var partial = vec4<f16>(0.0h);
partial = fma(weights[weightBase], vec4<f16>(inputValue.x), partial);
partial = fma(weights[weightBase + 1u], vec4<f16>(inputValue.y), partial);
partial = fma(weights[weightBase + 2u], vec4<f16>(inputValue.z), partial);
partial = fma(weights[weightBase + 3u], vec4<f16>(inputValue.w), partial);
acc += vec4<f32>(partial);
`}function Un(r,e,t){const i=t==="fp16"?"vec4<f16>":"vec4<f32>",n=t==="fp16"?`var partial = vec4<f16>(0.0h);
partial = fma(subgroupBroadcast(weights[weightBase], 0u), ${i}(inputValue.x), partial);
partial = fma(subgroupBroadcast(weights[weightBase + 1u], 0u), ${i}(inputValue.y), partial);
partial = fma(subgroupBroadcast(weights[weightBase + 2u], 0u), ${i}(inputValue.z), partial);
partial = fma(subgroupBroadcast(weights[weightBase + 3u], 0u), ${i}(inputValue.w), partial);
acc += vec4<f32>(partial);`:`acc = fma(subgroupBroadcast(weights[weightBase], 0u), vec4<f32>(inputValue.x), acc);
acc = fma(subgroupBroadcast(weights[weightBase + 1u], 0u), vec4<f32>(inputValue.y), acc);
acc = fma(subgroupBroadcast(weights[weightBase + 2u], 0u), vec4<f32>(inputValue.z), acc);
acc = fma(subgroupBroadcast(weights[weightBase + 3u], 0u), vec4<f32>(inputValue.w), acc);`;return`
let inputValue = ${i}(${r});
let weightBase = ${e};
${n}
`}function Ye(r,e,t){return r==="fp16"&&(e.loadMode==="packed-all"||t&&e.loadMode==="packed-weights")}function Oe(r,e){return e?`bitcast<vec4<f16>>(${r})`:r}function li(r,e){const{rowsPerThread:t,tileNBlocks:i,tileKBlocks:n}=ce(e);if(!e.unrollRows||e.accumulationOrder==="row-major")return Wn(r,e);const o=`(tileK * ${i}u + localId.x) * ${e.sharedLayout==="padded"||e.sharedLayout==="padded-weights"?5:4}u`,a=Array.from({length:t},(u,l)=>l),s=L(r);return`
    ${r==="fp16"?a.map(u=>`var partial${u} = vec4<f16>(0.0h);`).join(`
    `):""}
    for (var tileK = 0u; tileK < ${n}u; tileK++) {
      let weightBase = ${o};
      let w0 = weightTile[weightBase];
      let w1 = weightTile[weightBase + 1u];
      let w2 = weightTile[weightBase + 2u];
      let w3 = weightTile[weightBase + 3u];
      ${a.map(u=>{const l=Ke(`(localId.y * ${t}u + ${u}u) * ${n}u + tileK`,e),p=r==="fp16"?`partial${u}`:`acc[${u}]`;return`let v${u} = inputTile[${l}];
      `+["x","y","z","w"].map((c,d)=>`${p} = fma(w${d}, ${s}(v${u}.${c}), ${p});`).join(`
      `)}).join(`
      `)}
    }
    ${r==="fp16"?a.map(u=>`acc[${u}] += vec4<f32>(partial${u});`).join(`
    `):""}
`}function Wn(r,e){const{rowsPerThread:t,tileNBlocks:i,tileKBlocks:n}=ce(e),o=Ke(`tileSpatial * ${n}u + tileK`,e),a=`(tileK * ${i}u + localId.x) * ${e.sharedLayout==="padded"||e.sharedLayout==="padded-weights"?5:4}u`;if(e.accumulationOrder==="row-major"){const s=L(r),u=r==="fp16"?"partial":"acc[row]";return`
    for (var row = 0u; row < ${t}u; row++) {
      ${r==="fp16"?"var partial = vec4<f16>(0.0h);":""}
      let tileSpatial = localId.y * ${t}u + row;
      for (var tileK = 0u; tileK < ${n}u; tileK++) {
        let weightBase = ${a};
        let inputValue = inputTile[${o}];
        ${u} = fma(weightTile[weightBase], ${s}(inputValue.x), ${u});
        ${u} = fma(weightTile[weightBase + 1u], ${s}(inputValue.y), ${u});
        ${u} = fma(weightTile[weightBase + 2u], ${s}(inputValue.z), ${u});
        ${u} = fma(weightTile[weightBase + 3u], ${s}(inputValue.w), ${u});
      }
      ${r==="fp16"?"acc[row] += vec4<f32>(partial);":""}
    }
`}return r==="fp16"?`
    var partial: array<vec4<f16>, ${t}>;
    for (var row = 0u; row < ${t}u; row++) {
      partial[row] = vec4<f16>(0.0h);
    }
    for (var tileK = 0u; tileK < ${n}u; tileK++) {
      let weightBase =
        ${a};
      for (var row = 0u; row < ${t}u; row++) {
        let tileSpatial =
          localId.y * ${t}u + row;
        let inputValue =
          inputTile[${o}];
        partial[row] = fma(
          weightTile[weightBase],
          vec4<f16>(inputValue.x),
          partial[row]
        );
        partial[row] = fma(
          weightTile[weightBase + 1u],
          vec4<f16>(inputValue.y),
          partial[row]
        );
        partial[row] = fma(
          weightTile[weightBase + 2u],
          vec4<f16>(inputValue.z),
          partial[row]
        );
        partial[row] = fma(
          weightTile[weightBase + 3u],
          vec4<f16>(inputValue.w),
          partial[row]
        );
      }
    }
    for (var row = 0u; row < ${t}u; row++) {
      acc[row] += vec4<f32>(partial[row]);
    }
`:`
    for (var tileK = 0u; tileK < ${n}u; tileK++) {
      let weightBase =
        ${a};
      for (var row = 0u; row < ${t}u; row++) {
        let tileSpatial =
          localId.y * ${t}u + row;
        let inputValue =
          inputTile[${o}];
        acc[row] = fma(
          weightTile[weightBase],
          vec4<f32>(inputValue.x),
          acc[row]
        );
        acc[row] = fma(
          weightTile[weightBase + 1u],
          vec4<f32>(inputValue.y),
          acc[row]
        );
        acc[row] = fma(
          weightTile[weightBase + 2u],
          vec4<f32>(inputValue.z),
          acc[row]
        );
        acc[row] = fma(
          weightTile[weightBase + 3u],
          vec4<f32>(inputValue.w),
          acc[row]
        );
      }
    }
`}function Dn(r,e,t,i,n){const o=L(r),a=L(r),s=L(e),u=ae(le("acc",t),e);return`${fe(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}

@group(0) @binding(0) var<storage, read> inputData: array<${o}>;
@group(0) @binding(1) var<storage, read> weights: array<${a}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${s}>;
@group(0) @binding(4) var<uniform> params: Params;

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.outputWidth || gid.y >= params.outputHeight || gid.z >= ${n}u) {
    return;
  }
  var acc = bias[gid.z];
  for (var ky = 0u; ky < 3u; ky++) {
    let inputY = i32(gid.y) + i32(ky) - 1;
    if (inputY < 0 || inputY >= i32(params.inputHeight)) { continue; }
    for (var kx = 0u; kx < 3u; kx++) {
      let inputX = i32(gid.x) + i32(kx) - 1;
      if (inputX < 0 || inputX >= i32(params.inputWidth)) { continue; }
      let pixelBase = (u32(inputY) * params.inputWidth + u32(inputX)) * ${i}u;
      for (var inputBlock = 0u; inputBlock < ${i}u; inputBlock++) {
        ${ct("inputData[pixelBase + inputBlock]",`((((gid.z * 3u + ky) * 3u + kx) * ${i}u + inputBlock) * 4u)`,r)}
      }
    }
  }
  let outputIndex = (gid.y * params.outputWidth + gid.x) * ${n}u + gid.z;
  outputData[outputIndex] = ${u};
}
`}function Ln(r,e,t,i,n){const o=L(r),a=L(r),s=L(e),u=ae(le("acc",t),e);return`${fe(r)}
enable subgroups;
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${o}>;
@group(0) @binding(1) var<storage, read> weights: array<${a}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${s}>;
@group(0) @binding(4) var<uniform> params: Params;

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let outputInBounds =
    gid.x < params.outputWidth && gid.y < params.outputHeight;
  var acc = bias[gid.z];
  for (var ky = 0u; ky < 3u; ky++) {
    let inputY = i32(gid.y) + i32(ky) - 1;
    let clampedY = u32(clamp(inputY, 0, i32(params.inputHeight) - 1));
    for (var kx = 0u; kx < 3u; kx++) {
      let inputX = i32(gid.x) + i32(kx) - 1;
      let clampedX = u32(clamp(inputX, 0, i32(params.inputWidth) - 1));
      let inputInBounds =
        outputInBounds && inputX >= 0 && inputY >= 0 &&
        inputX < i32(params.inputWidth) && inputY < i32(params.inputHeight);
      let pixelBase =
        (clampedY * params.inputWidth + clampedX) * ${i}u;
      for (var inputBlock = 0u; inputBlock < ${i}u; inputBlock++) {
        ${Un(`select(${o}(0.0), inputData[pixelBase + inputBlock], inputInBounds)`,`((((gid.z * 3u + ky) * 3u + kx) * ${i}u + inputBlock) * 4u)`,r)}
      }
    }
  }
  if (outputInBounds) {
    let outputIndex =
      (gid.y * params.outputWidth + gid.x) * ${n}u + gid.z;
    outputData[outputIndex] = ${u};
  }
}
`}function Rn(r,e,t,i,n){const o=L(r),a=L(e),s=ae(le("acc",t),e),u=se*se*i,l=H*H;return`${fe(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${o}>;
@group(0) @binding(1) var<storage, read> weights: array<${o}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${a}>;
@group(0) @binding(4) var<uniform> params: Params;

var<workgroup> inputPatch: array<${o}, ${u}>;

@compute @workgroup_size(${H}, ${H}, 1)
fn main(
  @builtin(local_invocation_id) localId: vec3<u32>,
  @builtin(workgroup_id) workgroupId: vec3<u32>
) {
  let localLinear =
    localId.y * ${H}u + localId.x;
  for (
    var loadIndex = localLinear;
    loadIndex < ${u}u;
    loadIndex += ${l}u
  ) {
    let patchPixel = loadIndex / ${i}u;
    let inputBlock = loadIndex % ${i}u;
    let patchX = patchPixel % ${se}u;
    let patchY = patchPixel / ${se}u;
    let inputX =
      i32(workgroupId.x * ${H}u + patchX) - 1;
    let inputY =
      i32(workgroupId.y * ${H}u + patchY) - 1;
    var value = ${o}(0.0);
    if (
      inputX >= 0 && inputX < i32(params.inputWidth) &&
      inputY >= 0 && inputY < i32(params.inputHeight)
    ) {
      let inputIndex =
        (u32(inputY) * params.inputWidth + u32(inputX)) *
        ${i}u + inputBlock;
      value = inputData[inputIndex];
    }
    inputPatch[loadIndex] = value;
  }
  workgroupBarrier();

  let outputX =
    workgroupId.x * ${H}u + localId.x;
  let outputY =
    workgroupId.y * ${H}u + localId.y;
  let outputBlock = workgroupId.z;
  if (
    outputX >= params.outputWidth || outputY >= params.outputHeight ||
    outputBlock >= ${n}u
  ) {
    return;
  }

  var acc = bias[outputBlock];
  for (var ky = 0u; ky < 3u; ky++) {
    for (var kx = 0u; kx < 3u; kx++) {
      let patchBase =
        ((localId.y + ky) * ${se}u + localId.x + kx) *
        ${i}u;
      for (var inputBlock = 0u; inputBlock < ${i}u; inputBlock++) {
        ${ct("inputPatch[patchBase + inputBlock]",`((((outputBlock * 3u + ky) * 3u + kx) * ${i}u + inputBlock) * 4u)`,r)}
      }
    }
  }
  let outputIndex =
    (outputY * params.outputWidth + outputX) * ${n}u + outputBlock;
  outputData[outputIndex] = ${s};
}
`}function xr(r,e,t,i){const{workgroupX:n,workgroupY:o,tileM:a,tileKBlocks:s}=ce(t),u=e?"params.outputWidth":"params.inputWidth",l=e?"params.outputHeight":"params.inputHeight",p=t.addressMode==="base-offset",c=i?i.blocks.map((f,g)=>`cachedBase${g}[load] = (${g===i.upsampled?"y / 2u":"y"} * params.source${g}Width + ${g===i.upsampled?"x / 2u":"x"}) * ${f}u;`).join(`
    `):`cachedBase0[load] = (y * params.inputWidth + x) * ${r}u;`,d=a*s/(n*o);return`
  ${p?`var cachedBase0: array<u32, ${d}>;
  ${i?`var cachedBase1: array<u32, ${d}>;`:""}`:`var cachedX: array<u32, ${d}>;
  var cachedY: array<u32, ${d}>;`}
  var cachedMask: array<u32, ${d}>;
  for (var load = 0u; load < ${d}u; load++) {
    let loadIndex = localLinear + load * ${n*o}u;
    let spatial = workgroupId.x * ${a}u + loadIndex / ${s}u;
    let x = spatial % params.outputWidth;
    let y = spatial / params.outputWidth;
    ${p?c:`cachedX[load] = x;
    cachedY[load] = y;`}
    let columns =
      select(0u, 0x049u, x > 0u && x - 1u < ${u}) |
      select(0u, 0x092u, x < ${u}) |
      select(0u, 0x124u, x + 1u < ${u});
    let rows =
      select(0u, 0x007u, y > 0u && y - 1u < ${l}) |
      select(0u, 0x038u, y < ${l}) |
      select(0u, 0x1c0u, y + 1u < ${l});
    cachedMask[load] = select(0u, columns & rows, spatial < spatialCount)${p&&i?" | ((x & 1u) << 9u) | ((y & 1u) << 10u)":""};
  }
  var channelBlock = (localLinear % ${s}u) % ${r}u;
  var filterPosition = (localLinear % ${s}u) / ${r}u;
`}function vr(r,e){const{tileKBlocks:t}=ce(e);return`
    channelBlock += ${t%r}u;
    let carry = channelBlock >= ${r}u;
    channelBlock -= select(0u, ${r}u, carry);
    filterPosition += ${Math.floor(t/r)}u + select(0u, 1u, carry);
`}function vt(r,e,t){const{workgroupX:i,workgroupY:n,tileM:o,tileKBlocks:a}=ce(t);return`
    let inputBlock = channelBlock;
    let kernelY = filterPosition / 3u;
    let kernelX = filterPosition % 3u;
    for (var load = 0u; load < ${o*a/(i*n)}u; load++) {
      let loadIndex = localLinear + load * ${i*n}u;
      var value = ${r}(0.0);
      if (filterPosition < 9u && (cachedMask[load] & (1u << filterPosition)) != 0u) {
        ${t.addressMode==="base-offset"?"":`let inputX = i32(cachedX[load]) + i32(kernelX) - 1;
        let inputY = i32(cachedY[load]) + i32(kernelY) - 1;`}
        ${e}
      }
      inputTile[${Ke("loadIndex",t)}] = value;
    }
`}function Xn(r,e,t,i,n,o){const{workgroupX:a,workgroupY:s,rowsPerThread:u,tileM:l,tileNBlocks:p,tileKBlocks:c}=ce(o),{addressMode:d,weightLayout:f}=o,g=L(r),h=L(e),_=Ye(r,o,!1),$=Ye(r,o,!0),w=_?"vec2<u32>":g,y=$?"vec2<u32>":g,b=ae(le("acc",t),e),m=a*s,v=l*c,x=c*p*4;return`${fe(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${w}>;
@group(0) @binding(1) var<storage, read> weights: array<${y}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${h}>;
@group(0) @binding(4) var<uniform> params: Params;

var<workgroup> inputTile: array<${g}, ${ve(o).input}>;
var<workgroup> weightTile: array<${g}, ${ve(o).weights}>;

@compute @workgroup_size(${a}, ${s}, 1)
fn main(
  @builtin(local_invocation_id) localId: vec3<u32>,
  @builtin(workgroup_id) workgroupId: vec3<u32>
) {
  let spatialBase =
    workgroupId.x * ${l}u +
    localId.y * ${u}u;
  let outputBlock =
    workgroupId.y * ${p}u + localId.x;
  let spatialCount = params.outputWidth * params.outputHeight;
  var acc: array<vec4<f32>, ${u}>;
  if (outputBlock < ${n}u) {
    for (var row = 0u; row < ${u}u; row++) {
      acc[row] = bias[outputBlock];
    }
  }

  let localLinear =
    localId.y * ${a}u + localId.x;
  ${d!=="analytic"?xr(i,!1,o):""}
  let totalK = ${i*9}u;
  for (var kBase = 0u; kBase < totalK; kBase += ${c}u) {
    ${d!=="analytic"?vt(g,`
        ${d==="base-offset"?`let offset = (i32(kernelY) - 1) * i32(params.inputWidth) + i32(kernelX) - 1;
        let inputIndex = cachedBase0[load] + u32(offset * ${i}) + inputBlock;`:`let inputIndex = (u32(inputY) * params.inputWidth + u32(inputX)) *
          ${i}u + inputBlock;`}
        value = ${Oe("inputData[inputIndex]",_)};
    `,o):`
    for (
      var loadIndex = localLinear;
      loadIndex < ${v}u;
      loadIndex += ${m}u
    ) {
      let tileSpatial = loadIndex / ${c}u;
      let tileK = loadIndex % ${c}u;
      let inputSpatialIndex =
        workgroupId.x * ${l}u + tileSpatial;
      let kIndex = kBase + tileK;
      var value = ${g}(0.0);
      if (inputSpatialIndex < spatialCount && kIndex < totalK) {
        let outputY = inputSpatialIndex / params.outputWidth;
        let outputX = inputSpatialIndex % params.outputWidth;
        let inputBlock = kIndex % ${i}u;
        let kernelIndex = kIndex / ${i}u;
        let kernelY = kernelIndex / 3u;
        let kernelX = kernelIndex % 3u;
        let inputY = i32(outputY) + i32(kernelY) - 1;
        let inputX = i32(outputX) + i32(kernelX) - 1;
        if (
          inputY >= 0 && inputY < i32(params.inputHeight) &&
          inputX >= 0 && inputX < i32(params.inputWidth)
        ) {
          let inputIndex =
            (u32(inputY) * params.inputWidth + u32(inputX)) *
            ${i}u + inputBlock;
          value = ${Oe("inputData[inputIndex]",_)};
        }
      }
      inputTile[${Ke("loadIndex",o)}] = value;
    }
    `}

    for (
      var loadIndex = localLinear;
      loadIndex < ${x}u;
      loadIndex += ${m}u
    ) {
      let tileK = loadIndex / ${p*4}u;
      let outputRemainder = loadIndex % ${p*4}u;
      let tileOutputBlock = outputRemainder / 4u;
      let outputLane = outputRemainder % 4u;
      let loadedOutputBlock =
        workgroupId.y * ${p}u + tileOutputBlock;
      let kIndex = kBase + tileK;
      var value = ${g}(0.0);
      if (loadedOutputBlock < ${n}u && kIndex < totalK) {
        ${f==="k-major"?`
        let weightIndex = (kIndex * ${n}u + loadedOutputBlock) * 4u + outputLane;
        `:d!=="analytic"?`
        let weightIndex = (loadedOutputBlock * ${i*9}u + kIndex) * 4u + outputLane;
        `:`
        let inputBlock = kIndex % ${i}u;
        let kernelIndex = kIndex / ${i}u;
        let kernelY = kernelIndex / 3u;
        let kernelX = kernelIndex % 3u;
        let weightIndex =
          ((((loadedOutputBlock * 3u + kernelY) * 3u + kernelX) *
            ${i}u + inputBlock) * 4u + outputLane);
        `}
        value = ${Oe("weights[weightIndex]",$)};
      }
      weightTile[${si("loadIndex",o)}] = value;
    }

    workgroupBarrier();
    ${li(r,o)}
    workgroupBarrier();
    ${d!=="analytic"?vr(i,o):""}
  }

  if (outputBlock < ${n}u) {
    for (var row = 0u; row < ${u}u; row++) {
      let spatialIndex = spatialBase + row;
      if (spatialIndex < spatialCount) {
        let outputIndex = spatialIndex * ${n}u + outputBlock;
        outputData[outputIndex] = ${b.replaceAll("acc","acc[row]")};
      }
    }
  }
}
`}function Yn(r,e,t,i){const n=L(r),o=le("acc",e);return`${fe(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${n}>;
@group(0) @binding(1) var<storage, read> weights: array<${n}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${n}>;
@group(0) @binding(4) var<uniform> params: Params;

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.outputWidth || gid.y >= params.outputHeight || gid.z >= ${i}u) {
    return;
  }
  var pooled = vec4<f32>(-3.402823466e+38);
  for (var py = 0u; py < 2u; py++) {
    let centerY = gid.y * 2u + py;
    if (centerY >= params.inputHeight) { continue; }
    for (var px = 0u; px < 2u; px++) {
      let centerX = gid.x * 2u + px;
      if (centerX >= params.inputWidth) { continue; }
      var acc = bias[gid.z];
      for (var ky = 0u; ky < 3u; ky++) {
        let inputY = i32(centerY) + i32(ky) - 1;
        if (inputY < 0 || inputY >= i32(params.inputHeight)) { continue; }
        for (var kx = 0u; kx < 3u; kx++) {
          let inputX = i32(centerX) + i32(kx) - 1;
          if (inputX < 0 || inputX >= i32(params.inputWidth)) { continue; }
          let pixelBase = (u32(inputY) * params.inputWidth + u32(inputX)) * ${t}u;
          for (var inputBlock = 0u; inputBlock < ${t}u; inputBlock++) {
            ${ct("inputData[pixelBase + inputBlock]",`((((gid.z * 3u + ky) * 3u + kx) * ${t}u + inputBlock) * 4u)`,r)}
          }
        }
      }
      pooled = max(pooled, ${o});
    }
  }
  let outputIndex = (gid.y * params.outputWidth + gid.x) * ${i}u + gid.z;
  outputData[outputIndex] = ${ae("pooled",r)};
}
`}function Fn(r,e,t){const i=L(r);return`${fe(r)}
struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${i}>;
@group(0) @binding(1) var<storage, read_write> outputData: array<${i}>;
@group(0) @binding(2) var<uniform> params: Params;

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(
  @builtin(global_invocation_id) gid: vec3<u32>${t?`,
  @builtin(num_workgroups) groupCount: vec3<u32>`:""}
) {
  ${t?`let linearX = gid.x + gid.z * groupCount.x * ${Q}u;
  let outputBlock = linearX % ${e}u;
  let outputX = linearX / ${e}u;`:`let outputBlock = gid.z;
  let outputX = gid.x;`}
  if (
    outputX >= params.outputWidth ||
    gid.y >= params.outputHeight ||
    outputBlock >= ${e}u
  ) {
    return;
  }
  var pooled = vec4<f32>(-3.402823466e+38);
  for (var py = 0u; py < 2u; py++) {
    let inputY = gid.y * 2u + py;
    if (inputY >= params.inputHeight) { continue; }
    for (var px = 0u; px < 2u; px++) {
      let inputX = outputX * 2u + px;
      if (inputX >= params.inputWidth) { continue; }
      let inputIndex =
        (inputY * params.inputWidth + inputX) * ${e}u + outputBlock;
      pooled = max(pooled, vec4<f32>(inputData[inputIndex]));
    }
  }
  let outputIndex =
    (gid.y * params.outputWidth + outputX) * ${e}u + outputBlock;
  outputData[outputIndex] = ${ae("pooled",r)};
}
`}function Gn(r,e,t,i,n,o,a){const{workgroupX:s,workgroupY:u,rowsPerThread:l,tileM:p,tileNBlocks:c,tileKBlocks:d}=ce(a),{addressMode:f,weightLayout:g}=a,h=L(r),_=L(e),$=Ye(r,a,!1),w=Ye(r,a,!0),y=$?"vec2<u32>":h,b=w?"vec2<u32>":h,m=i[0]+i[1],v=ae(le("acc[row]",t),e),x=s*u,k=p*d,B=d*c*4,P=(T,U)=>`
          {
            let sourceBlock = ${U};
            ${f==="base-offset"?`let dx = ${T===n?"(i32((cachedMask[load] >> 9u) & 1u) + i32(kernelX) - 1) >> 1u":"i32(kernelX) - 1"};
            let dy = ${T===n?"(i32((cachedMask[load] >> 10u) & 1u) + i32(kernelY) - 1) >> 1u":"i32(kernelY) - 1"};
            let offset = (dy * i32(params.source${T}Width) + dx) * ${i[T]};
            let sourceIndex = cachedBase${T}[load] + u32(offset) + sourceBlock;`:`let sourceX = ${T===n?"u32(inputX) / 2u":"u32(inputX)"};
            let sourceY = ${T===n?"u32(inputY) / 2u":"u32(inputY)"};
            let sourceIndex =
              (sourceY * params.source${T}Width + sourceX) *
              ${i[T]}u + sourceBlock;`}
            value = ${Oe(`input${T}[sourceIndex]`,$)};
          }`;return`${fe(r)}
struct Params {
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
  inputBlocks: u32,
  source0Width: u32,
  source0Height: u32,
  source1Width: u32,
  source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${y}>;
@group(0) @binding(1) var<storage, read> input1: array<${y}>;
@group(0) @binding(2) var<storage, read> weights: array<${b}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${_}>;
@group(0) @binding(5) var<uniform> params: Params;

var<workgroup> inputTile: array<${h}, ${ve(a).input}>;
var<workgroup> weightTile: array<${h}, ${ve(a).weights}>;

@compute @workgroup_size(${s}, ${u}, 1)
fn main(
  @builtin(local_invocation_id) localId: vec3<u32>,
  @builtin(workgroup_id) workgroupId: vec3<u32>
) {
  let spatialBase =
    workgroupId.x * ${p}u +
    localId.y * ${l}u;
  let outputBlock =
    workgroupId.y * ${c}u + localId.x;
  let spatialCount = params.outputWidth * params.outputHeight;
  var acc: array<vec4<f32>, ${l}>;
  if (outputBlock < ${o}u) {
    for (var row = 0u; row < ${l}u; row++) {
      acc[row] = bias[outputBlock];
    }
  }

  let localLinear =
    localId.y * ${s}u + localId.x;
  ${f!=="analytic"?xr(m,!0,a,{blocks:i,upsampled:n}):""}
  let totalK = ${m*9}u;
  for (var kBase = 0u; kBase < totalK; kBase += ${d}u) {
    ${f!=="analytic"?a.decoderLoad==="source-first"?`
    if (channelBlock < ${i[0]}u) {
      ${vt(h,P(0,"inputBlock"),a)}
    } else {
      ${vt(h,P(1,`inputBlock - ${i[0]}u`),a)}
    }
    `:vt(h,`
        if (inputBlock < ${i[0]}u) {
          ${P(0,"inputBlock")}
        } else {
          ${P(1,`inputBlock - ${i[0]}u`)}
        }
    `,a):`
    for (
      var loadIndex = localLinear;
      loadIndex < ${k}u;
      loadIndex += ${x}u
    ) {
      let tileSpatial = loadIndex / ${d}u;
      let tileK = loadIndex % ${d}u;
      let outputSpatialIndex =
        workgroupId.x * ${p}u + tileSpatial;
      let kIndex = kBase + tileK;
      var value = ${h}(0.0);
      if (outputSpatialIndex < spatialCount && kIndex < totalK) {
        let outputY = outputSpatialIndex / params.outputWidth;
        let outputX = outputSpatialIndex % params.outputWidth;
        let inputBlock = kIndex % ${m}u;
        let kernelIndex = kIndex / ${m}u;
        let kernelY = kernelIndex / 3u;
        let kernelX = kernelIndex % 3u;
        let inputY = i32(outputY) + i32(kernelY) - 1;
        let inputX = i32(outputX) + i32(kernelX) - 1;
        if (
          inputY >= 0 && inputY < i32(params.outputHeight) &&
          inputX >= 0 && inputX < i32(params.outputWidth)
        ) {
          if (inputBlock < ${i[0]}u) {
            ${P(0,"inputBlock")}
          } else {
            ${P(1,`inputBlock - ${i[0]}u`)}
          }
        }
      }
      inputTile[${Ke("loadIndex",a)}] = value;
    }
    `}

    for (
      var loadIndex = localLinear;
      loadIndex < ${B}u;
      loadIndex += ${x}u
    ) {
      let tileK = loadIndex / ${c*4}u;
      let outputRemainder = loadIndex % ${c*4}u;
      let tileOutputBlock = outputRemainder / 4u;
      let outputLane = outputRemainder % 4u;
      let loadedOutputBlock =
        workgroupId.y * ${c}u + tileOutputBlock;
      let kIndex = kBase + tileK;
      var value = ${h}(0.0);
      if (loadedOutputBlock < ${o}u && kIndex < totalK) {
        ${g==="k-major"?`
        let weightIndex = (kIndex * ${o}u + loadedOutputBlock) * 4u + outputLane;
        `:f!=="analytic"?`
        let weightIndex = (loadedOutputBlock * ${m*9}u + kIndex) * 4u + outputLane;
        `:`
        let inputBlock = kIndex % ${m}u;
        let kernelIndex = kIndex / ${m}u;
        let kernelY = kernelIndex / 3u;
        let kernelX = kernelIndex % 3u;
        let weightIndex =
          ((((loadedOutputBlock * 3u + kernelY) * 3u + kernelX) *
            ${m}u + inputBlock) * 4u + outputLane);
        `}
        value = ${Oe("weights[weightIndex]",w)};
      }
      weightTile[${si("loadIndex",a)}] = value;
    }

    workgroupBarrier();
    ${li(r,a)}
    workgroupBarrier();
    ${f!=="analytic"?vr(m,a):""}
  }

  if (outputBlock < ${o}u) {
    for (var row = 0u; row < ${l}u; row++) {
      let spatialIndex = spatialBase + row;
      if (spatialIndex < spatialCount) {
        let outputIndex = spatialIndex * ${o}u + outputBlock;
        outputData[outputIndex] = ${v};
      }
    }
  }
}
`}function Hn(r,e,t,i,n,o,a){const s=ce(a),{workgroupX:u,workgroupY:l,rowsPerThread:p,tileM:c,tileNBlocks:d,tileKBlocks:f}=s,g=u*l,h=c*f/g,_=L(r),$=Ye(r,a,!1),w=Ye(r,a,!0),y=i[n],b=1-n;i[b];const m=(x,k)=>{const B=i[x],P=k?4:9,T=k?`phase * ${4*y*o*4}u`:`${ot*y*o*4}u`,U=k?`(i32(tap / 2u) + i32(phaseY) - 1) * i32(params.source${x}Width) + i32(tap % 2u) + i32(phaseX) - 1`:`(i32(tap / 3u) - 1) * i32(params.source${x}Width) + i32(tap % 3u) - 1`;return`
  for (var kBase = 0u; kBase < ${P*B}u; kBase += ${f}u) {
    let inputK = kBase + localLinear % ${f}u;
    let tap = inputK / ${B}u;
    let channel = inputK % ${B}u;
    for (var load = 0u; load < ${h}u; load++) {
      let i = localLinear + load * ${g}u;
      var value = ${_}(0.0);
      if (tap < ${P}u && (mask${x}[load] & (1u << tap)) != 0u) {
        let offset = ${U};
        let index = u32(base${x}[load] + offset) * ${B}u + channel;
        value = ${Oe(`input${x}[index]`,$)};
      }
      inputTile[${Ke("i",a)}] = value;
    }
    for (var i = localLinear; i < ${f*d*4}u; i += ${g}u) {
      let k = kBase + i / ${d*4}u;
      let outputBlock = workgroupId.y * ${d}u + (i % ${d*4}u) / 4u;
      var value = ${_}(0.0);
      if (k < ${P*B}u && outputBlock < ${o}u) {
        let index = ${T} + (k * ${o}u + outputBlock) * 4u + i % 4u;
        value = ${Oe("weights[index]",w)};
      }
      weightTile[${si("i",a)}] = value;
    }
    workgroupBarrier();
    ${li(r,a)}
    workgroupBarrier();
  }`},v=(x,k)=>{const B=k?4:9,P=k?2:3;return`
    let x${x} = i32(${k?"x":"x * 2u + phaseX"});
    let y${x} = i32(${k?"y":"y * 2u + phaseY"});
    base${x}[load] = y${x} * i32(params.source${x}Width) + x${x};
    var bits${x} = 0u;
    for (var tap = 0u; tap < ${B}u; tap++) {
      let sx = x${x} + i32(tap % ${P}u) ${k?"+ i32(phaseX)":""} - 1;
      let sy = y${x} + i32(tap / ${P}u) ${k?"+ i32(phaseY)":""} - 1;
      if (valid && sx >= 0 && sy >= 0 && sx < i32(params.source${x}Width) && sy < i32(params.source${x}Height)) {
        bits${x} |= 1u << tap;
      }
    }
    mask${x}[load] = bits${x};`};return`${fe(r)}
struct Params {
  outputWidth: u32, outputHeight: u32, outputBlocks: u32, inputBlocks: u32,
  source0Width: u32, source0Height: u32, source1Width: u32, source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${$?"vec2<u32>":_}>;
@group(0) @binding(1) var<storage, read> input1: array<${$?"vec2<u32>":_}>;
@group(0) @binding(2) var<storage, read> weights: array<${w?"vec2<u32>":_}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${L(e)}>;
@group(0) @binding(5) var<uniform> params: Params;
var<workgroup> inputTile: array<${_}, ${ve(a).input}>;
var<workgroup> weightTile: array<${_}, ${ve(a).weights}>;

@compute @workgroup_size(${u}, ${l}, 1)
fn main(@builtin(local_invocation_id) localId: vec3<u32>, @builtin(workgroup_id) workgroupId: vec3<u32>) {
  let phase = workgroupId.z;
  let phaseX = phase & 1u;
  let phaseY = phase >> 1u;
  let phaseWidth = (params.outputWidth + 1u) / 2u;
  let localLinear = localId.y * ${u}u + localId.x;
  let outputBlock = workgroupId.y * ${d}u + localId.x;
  var acc: array<vec4<f32>, ${p}>;
  if (outputBlock < ${o}u) {
    for (var row = 0u; row < ${p}u; row++) { acc[row] = bias[outputBlock]; }
  }
  var base0: array<i32, ${h}>;
  var base1: array<i32, ${h}>;
  var mask0: array<u32, ${h}>;
  var mask1: array<u32, ${h}>;
  for (var load = 0u; load < ${h}u; load++) {
    let spatial = workgroupId.x * ${c}u + (localLinear + load * ${g}u) / ${f}u;
    let x = spatial % phaseWidth;
    let y = spatial / phaseWidth;
    let valid = x * 2u + phaseX < params.outputWidth && y * 2u + phaseY < params.outputHeight;
    ${v(n,!0)}
    ${v(b,!1)}
  }
  ${m(n,!0)}
  ${m(b,!1)}
  if (outputBlock < ${o}u) {
    for (var row = 0u; row < ${p}u; row++) {
      let spatial = workgroupId.x * ${c}u + localId.y * ${p}u + row;
      let x = (spatial % phaseWidth) * 2u + phaseX;
      let y = (spatial / phaseWidth) * 2u + phaseY;
      if (x < params.outputWidth && y < params.outputHeight) {
        outputData[(y * params.outputWidth + x) * ${o}u + outputBlock] = ${ae(le("acc[row]",t),e)};
      }
    }
  }
}
`}function Vn(r,e,t,i,n,o){const a=L(r),s=L(e),u=i[0]+i[1],l=(c,d)=>{const f=c===n;return`
      {
        let sourceX = ${f?"u32(inputX) / 2u":"u32(inputX)"};
        let sourceY = ${f?"u32(inputY) / 2u":"u32(inputY)"};
        let sourcePixelBase = (sourceY * params.source${c}Width + sourceX) * ${i[c]}u;
        for (var sourceBlock = 0u; sourceBlock < ${i[c]}u; sourceBlock++) {
          let inputBlock = ${d}u + sourceBlock;
          ${ct(`input${c}[sourcePixelBase + sourceBlock]`,`((((gid.z * 3u + ky) * 3u + kx) * ${u}u + inputBlock) * 4u)`,r)}
        }
      }
`},p=ae(le("acc",t),e);return`${fe(r)}
struct Params {
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
  inputBlocks: u32,
  source0Width: u32,
  source0Height: u32,
  source1Width: u32,
  source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${a}>;
@group(0) @binding(1) var<storage, read> input1: array<${a}>;
@group(0) @binding(2) var<storage, read> weights: array<${a}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${s}>;
@group(0) @binding(5) var<uniform> params: Params;

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.outputWidth || gid.y >= params.outputHeight || gid.z >= ${o}u) {
    return;
  }
  var acc = bias[gid.z];
  for (var ky = 0u; ky < 3u; ky++) {
    let inputY = i32(gid.y) + i32(ky) - 1;
    if (inputY < 0 || inputY >= i32(params.outputHeight)) { continue; }
    for (var kx = 0u; kx < 3u; kx++) {
      let inputX = i32(gid.x) + i32(kx) - 1;
      if (inputX < 0 || inputX >= i32(params.outputWidth)) { continue; }
      ${l(0,0)}
      ${l(1,i[0])}
    }
  }
  let outputIndex = (gid.y * params.outputWidth + gid.x) * ${o}u + gid.z;
  outputData[outputIndex] = ${p};
}
`}function jn(r,e,t,i,n,o){const a=L(r),s=L(e),u=i[0]+i[1],l=se*se*u,p=H*H,c=ae(le("acc",t),e),d=(f,g)=>`
      let sourceBlock = ${g};
      let sourceIndex =
        (${f===n?"u32(inputY) / 2u":"u32(inputY)"} * params.source${f}Width + ${f===n?"u32(inputX) / 2u":"u32(inputX)"}) *
        ${i[f]}u + sourceBlock;
      value = input${f}[sourceIndex];`;return`${fe(r)}
struct Params {
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
  inputBlocks: u32,
  source0Width: u32,
  source0Height: u32,
  source1Width: u32,
  source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${a}>;
@group(0) @binding(1) var<storage, read> input1: array<${a}>;
@group(0) @binding(2) var<storage, read> weights: array<${a}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${s}>;
@group(0) @binding(5) var<uniform> params: Params;

var<workgroup> inputPatch: array<${a}, ${l}>;

@compute @workgroup_size(${H}, ${H}, 1)
fn main(
  @builtin(local_invocation_id) localId: vec3<u32>,
  @builtin(workgroup_id) workgroupId: vec3<u32>
) {
  let localLinear =
    localId.y * ${H}u + localId.x;
  for (
    var loadIndex = localLinear;
    loadIndex < ${l}u;
    loadIndex += ${p}u
  ) {
    let patchPixel = loadIndex / ${u}u;
    let inputBlock = loadIndex % ${u}u;
    let patchX = patchPixel % ${se}u;
    let patchY = patchPixel / ${se}u;
    let inputX =
      i32(workgroupId.x * ${H}u + patchX) - 1;
    let inputY =
      i32(workgroupId.y * ${H}u + patchY) - 1;
    var value = ${a}(0.0);
    if (
      inputX >= 0 && inputX < i32(params.outputWidth) &&
      inputY >= 0 && inputY < i32(params.outputHeight)
    ) {
      if (inputBlock < ${i[0]}u) {
        ${d(0,"inputBlock")}
      } else {
        ${d(1,`inputBlock - ${i[0]}u`)}
      }
    }
    inputPatch[loadIndex] = value;
  }
  workgroupBarrier();

  let outputX =
    workgroupId.x * ${H}u + localId.x;
  let outputY =
    workgroupId.y * ${H}u + localId.y;
  let outputBlock = workgroupId.z;
  if (
    outputX >= params.outputWidth || outputY >= params.outputHeight ||
    outputBlock >= ${o}u
  ) {
    return;
  }

  var acc = bias[outputBlock];
  for (var ky = 0u; ky < 3u; ky++) {
    for (var kx = 0u; kx < 3u; kx++) {
      let patchBase =
        ((localId.y + ky) * ${se}u + localId.x + kx) *
        ${u}u;
      for (var inputBlock = 0u; inputBlock < ${u}u; inputBlock++) {
        ${ct("inputPatch[patchBase + inputBlock]",`((((outputBlock * 3u + ky) * 3u + kx) * ${u}u + inputBlock) * 4u)`,r)}
      }
    }
  }
  let outputIndex =
    (outputY * params.outputWidth + outputX) * ${o}u + outputBlock;
  outputData[outputIndex] = ${c};
}
`}function br(r,e){const t=L(r),i=Array.from({length:e},(s,u)=>`@group(0) @binding(${u}) var<storage, read> input${u}: array<vec4<f32>>;`).join(`
`),n=Array.from({length:e},(s,u)=>{const l=u*3;return`if (channel < ${l+3}u) { return input${u}[pixel][channel - ${l}u]; }`}).join(`
  `),o=e,a=e+1;return`${fe(r)}
struct Params {
  width: u32,
  height: u32,
  outputBlocks: u32,
  inputChannels: u32,
}
${i}
@group(0) @binding(${o}) var<storage, read_write> outputData: array<${t}>;
@group(0) @binding(${a}) var<uniform> params: Params;

fn readChannel(pixel: u32, channel: u32) -> f32 {
  ${n}
  return 0.0;
}

@compute @workgroup_size(${Q}, ${Q}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.width || gid.y >= params.height || gid.z >= params.outputBlocks) {
    return;
  }
  let pixel = gid.y * params.width + gid.x;
  let firstChannel = gid.z * 4u;
  let value = vec4<f32>(
    readChannel(pixel, firstChannel),
    readChannel(pixel, firstChannel + 1u),
    readChannel(pixel, firstChannel + 2u),
    readChannel(pixel, firstChannel + 3u)
  );
  outputData[pixel * params.outputBlocks + gid.z] = ${ae("value",r)};
}
`}const Kn="chromium-experimental-subgroup-matrix",qn="wgpu-cooperative-matrix",Fe=32,Ge=8,Ne=4,Zn=1024;function Qn(r,e="f32"){const t=r.features.has(Kn)?"tint":r.features.has(qn)?"naga":void 0;if(!t||!r.features.has("subgroups"))return;const i=r.adapterInfo,n=i?.subgroupMaxSize??0;if(!i||!n||i.subgroupMinSize!==n)return;const o=e==="f16"?[["f16","f16"],["f16","f32"],["f32","f32"]]:[["f16","f32"],["f32","f32"],["f16","f16"]],a=r.features.has("shader-f16");for(const[s,u]of o)if(!(!a&&(s==="f16"||u==="f16"))){for(const l of[8,16])if(i.subgroupMatrixConfigs?.find(c=>c.componentType===s&&c.resultComponentType===u&&c.M===l&&c.N===l&&c.K===l))return{componentType:s,resultType:u,size:l,subgroupSize:n,dialect:t}}}function Jn(r,e){return e.outputFragments??2}function eo(r,e,t,i){const n=r.componentType==="f16"?2:4,o=r.resultType==="f16"?2:4,a=r.size,s=(Ge+2)*(Fe+2)*a,u=t?16:9;return n*(i?2:1)*(s+u*a*a*e)+o*Ne*Fe*a}function kr(r){const e=r.size,t=r.dialect==="naga",i=(o,a,s)=>t?`coop_mat${e}x${e}<${o}, ${s}>`:`subgroup_matrix_${a}<${o}, ${e}, ${e}>`,n=i(r.resultType,"result","C");return{left:i(r.componentType,"left","A"),right:i(r.componentType,"right","B"),result:n,load:(o,a,s,u)=>t?`coopLoadT<${o}>(&${a}[${s}], ${u})`:`subgroupMatrixLoad<${o}, row_major>(&${a}, ${s}, ${u})`,store:(o,a,s,u)=>t?`coopStoreT(${s}, &${o}[${a}], ${u});`:`subgroupMatrixStore<row_major>(&${o}, ${a}, ${s}, ${u});`,multiplyAdd:t?"coopMultiplyAdd":"subgroupMatrixMultiplyAccumulate",declare:o=>t?`var ${o}: ${n};`:`var ${o} = ${n}();`,extensions:t?"enable wgpu_cooperative_matrix;":`enable subgroups;
enable chromium_experimental_subgroup_matrix;
diagnostic(off, chromium_experimental.subgroup_matrix_uniformity);`}}function Gt(r,e,t,i,n,o,a){const s=(g,h,_)=>`{
        let staged = vec4<${o}>(${h});
        let base = ${_} + i * 4u;
        ${g.array}[base] = staged.x;
        ${g.array}[base + 1u] = staged.y;
        ${g.array}[base + 2u] = staged.z;
        ${g.array}[base + 3u] = staged.w;
      }`,u=g=>e.map(h=>`
    for (var batch = 0u; batch < ${Math.ceil(h.vectors/i)}u; batch++) {
      let i = localIndex + batch * ${i}u;
      if (i < ${h.vectors}u) {
        var value = ${n}(0.0);
        ${h.read}
        ${s(h,"value",g(h))}
      }
    }`).join(""),l=g=>e.map(h=>`let ${h.array}Base = ${g} * ${(h.stride??h.vectors)*4}u;`).join(`
    `);if(!a||r<2)return`
  for (var chunk = 0u; chunk < ${r}u; chunk++) {
    let stageChunk = chunk;
    ${l("0u")}
    ${u(g=>`${g.array}Base`)}
    workgroupBarrier();
    ${t}
    workgroupBarrier();
  }`;const p=e.map(g=>Math.ceil(g.vectors/i)),c=e.map((g,h)=>Array.from({length:p[h]},(_,$)=>`
      {
        let i = localIndex + ${$*i}u;
        var value = ${n}(0.0);
        if (i < ${g.vectors}u) {
          ${g.read}
        }
        prefetch${h}_${$} = value;
      }`).join("")).join(""),d=e.map((g,h)=>Array.from({length:p[h]},(_,$)=>`var prefetch${h}_${$} = ${n}(0.0);`).join(`
    `)).join(`
    `),f=e.map((g,h)=>Array.from({length:p[h]},(_,$)=>`
      {
        let i = localIndex + ${$*i}u;
        if (i < ${g.vectors}u) ${s(g,`prefetch${h}_${$}`,`next * ${(g.stride??g.vectors)*4}u`)}
      }`).join("")).join("");return`
  {
    let stageChunk = 0u;
    ${u(()=>"0u")}
  }
  workgroupBarrier();
  for (var chunk = 0u; chunk < ${r}u; chunk++) {
    let buffer = chunk & 1u;
    let next = 1u - buffer;
    ${l("buffer")}
    ${d}
    if (chunk + 1u < ${r}u) {
      let stageChunk = chunk + 1u;
      ${c}
    }
    ${t}
    if (chunk + 1u < ${r}u) {
      ${f}
    }
    workgroupBarrier();
  }`}function Tr(r,e){return r.dialect==="naga"?Array.from({length:9},(t,i)=>`{ let tap = ${i}u; ${e} }`).join(`
`):`for (var tap = 0u; tap < 9u; tap++) { ${e} }`}function to(r,e,t,i,n,o,a,s,u,l=!1){const p=o.size,c=o.componentType,d=o.resultType,f=Fe,g=f+2,h=Ge+2,_=s?2:1,$=p/4,w=Math.ceil(i/$),y=a*p,b=f/p,m=Ne*o.subgroupSize,v=L(r),x=L(e),{left:k,right:B,load:P,store:T,multiplyAdd:U,declare:j,extensions:ne}=kr(o),ie=[];for(let A=0;A<2;A++)for(let Y=0;Y<b;Y++)for(let W=0;W<a;W++)ie.push(`acc${A}_${Y}_${W}`);const pe=ie.map(j).join(`
  `),K=Array.from({length:a},(A,Y)=>`let b${Y} = ${P(B,"weightTile",`weightTileBase + tap * ${p*y}u + ${Y*p}u`,`${y}u`)};`).join(`
      `),te=[];for(let A=0;A<2;A++)for(let Y=0;Y<b;Y++)te.push(`{
        let a = ${P(k,"inputTile",`inputTileBase + ((rowBase + ${A}u + ky) * ${g}u + ${Y*p}u + kx) * ${p}u`,`${p}u`)};
        ${Array.from({length:a},(W,G)=>`acc${A}_${Y}_${G} = ${U}(a, b${G}, acc${A}_${Y}_${G});`).join(`
        `)}
      }`);const be=`let ky = tap / 3u;
      let kx = tap % 3u;
      ${K}
      ${te.join(`
      `)}`,Ue=Tr(o,be),R=[];if(l)for(let A=0;A<a;A++)R.push(`{
    var pooled = vec4<f32>(-3.402823e38);
    let pixel = lane / ${$}u;
    let outputBlock = blockBase + ${A*$}u + lane % ${$}u;
    ${Array.from({length:2},(Y,W)=>`
    ${Array.from({length:b},(G,Ce)=>T("resultTile",`resultBase + ${Ce*p*p}u`,`acc${W}_${Ce}_${A}`,`${p}u`)).join(`
    `)}
    workgroupBarrier();
    {
      let base = resultBase + pixel * ${p*2}u + (lane % ${$}u) * 4u;
      let first = vec4<f32>(resultTile[base], resultTile[base + 1u], resultTile[base + 2u], resultTile[base + 3u]);
      let second = vec4<f32>(resultTile[base + ${p}u], resultTile[base + ${p+1}u], resultTile[base + ${p+2}u], resultTile[base + ${p+3}u]);
      if (tileY + rowBase + ${W}u < params.inputHeight) {
        pooled = max(pooled, first);
        if (tileX + pixel * 2u + 1u < params.inputWidth) { pooled = max(pooled, second); }
      }
    }
    workgroupBarrier();`).join(`
    `)}
    let outputX = tileX / 2u + pixel;
    let outputY = (tileY + rowBase) / 2u;
    if (outputX < params.outputWidth && outputY < params.outputHeight && outputBlock < ${n}u) {
      let acc = pooled + bias[outputBlock];
      outputData[(outputY * params.outputWidth + outputX) * ${n}u + outputBlock] = ${ae(le("acc",t),e)};
    }
  }`);else for(let A=0;A<2;A++)for(let Y=0;Y<a;Y++)R.push(`{
    ${Array.from({length:b},(W,G)=>T("resultTile",`resultBase + ${G*p*p}u`,`acc${A}_${G}_${Y}`,`${p}u`)).join(`
    `)}
    workgroupBarrier();
    let outputY = tileY + rowBase + ${A}u;
    for (var e = lane; e < ${f*$}u; e += ${o.subgroupSize}u) {
      let pixel = e / ${$}u;
      let outputX = tileX + pixel;
      let outputBlock = blockBase + ${Y*$}u + e % ${$}u;
      if (outputX < params.outputWidth && outputY < params.outputHeight && outputBlock < ${n}u) {
        let base = resultBase + pixel * ${p}u + (e % ${$}u) * 4u;
        let acc = vec4<f32>(f32(resultTile[base]), f32(resultTile[base + 1u]),
          f32(resultTile[base + 2u]), f32(resultTile[base + 3u])) + bias[outputBlock];
        outputData[(outputY * params.outputWidth + outputX) * ${n}u + outputBlock] = ${ae(le("acc",t),e)};
      }
    }
    workgroupBarrier();
  }`);const V=u?(()=>{const[A,Y]=u.sourceBlocks,W=G=>G===u.upsampledSource?`min(u32(inputY) / 2u, params.source${G}Height - 1u) * params.source${G}Width + min(u32(inputX) / 2u, params.source${G}Width - 1u)`:`u32(inputY) * params.source${G}Width + u32(inputX)`;return`if (block < ${A}u) {
          value = input0[(${W(0)}) * ${A}u + block];
        } else {
          value = input1[(${W(1)}) * ${Y}u + block - ${A}u];
        }`})():`value = inputData[(u32(inputY) * params.inputWidth + u32(inputX)) * ${i}u + block];`,Se=u?`struct Params {
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
  inputBlocks: u32,
  source0Width: u32,
  source0Height: u32,
  source1Width: u32,
  source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${v}>;
@group(0) @binding(1) var<storage, read> input1: array<${v}>;
@group(0) @binding(2) var<storage, read> weights: array<${v}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${x}>;
@group(0) @binding(5) var<uniform> params: Params;`:`struct Params {
  inputWidth: u32,
  inputHeight: u32,
  outputWidth: u32,
  outputHeight: u32,
  inputBlocks: u32,
  outputBlocks: u32,
}
@group(0) @binding(0) var<storage, read> inputData: array<${v}>;
@group(0) @binding(1) var<storage, read> weights: array<${v}>;
@group(0) @binding(2) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> outputData: array<${x}>;
@group(0) @binding(4) var<uniform> params: Params;`,We=u?"params.outputWidth":"params.inputWidth",De=u?"params.outputHeight":"params.inputHeight";return`${r==="fp16"||e==="fp16"||c==="f16"||d==="f16"?`enable f16;
`:""}${ne}
${Se}

var<workgroup> inputTile: array<${c}, ${_*h*g*p}>;
var<workgroup> weightTile: array<${c}, ${_*9*p*y}>;
var<workgroup> resultTile: array<${d}, ${Ne*f*p}>;

@compute @workgroup_size(${m})
fn main(
  @builtin(local_invocation_index) localIndex: u32,
  @builtin(workgroup_id) workgroupId: vec3<u32>,
  @builtin(subgroup_id) subgroup: u32,
  @builtin(subgroup_invocation_id) lane: u32
) {
  let tileX = workgroupId.x * ${f}u;
  let tileY = workgroupId.y * ${Ge}u;
  let blockBase = workgroupId.z * ${y/4}u;
  let rowBase = subgroup * 2u;
  let resultBase = subgroup * ${f*p}u;
  ${pe}

  ${Gt(w,[{array:"inputTile",vectors:h*g*$,read:`let pixel = i / ${$}u;
      let block = stageChunk * ${$}u + i % ${$}u;
      let inputX = i32(tileX + pixel % ${g}u) - 1;
      let inputY = i32(tileY + pixel / ${g}u) - 1;
      if (block < ${i}u && inputX >= 0 && inputY >= 0 &&
          inputX < i32(${We}) && inputY < i32(${De})) {
        ${V}
      }`},{array:"weightTile",vectors:9*p*y/4,read:`let quad = i % ${y/4}u;
      let row = i / ${y/4}u;
      let tap = row / ${p}u;
      let inputChannel = stageChunk * ${p}u + row % ${p}u;
      let outputBlock = blockBase + quad;
      if (inputChannel < ${i*4}u && outputBlock < ${n}u) {
        value = weights[((tap * ${i}u + inputChannel / 4u) * ${n}u + outputBlock) * 4u + inputChannel % 4u];
      }`}],Ue,m,v,c,s)}

  ${R.join(`
  `)}
}
`}const gt=[[-1,0],[0,1]],Ei=[[[0],[1,2]],[[0,1],[2]]],ot=16;function io(r,e,t,i,n,o){const a=M(t.outputChannels),s=n[o],u=n[1-o],l=o===0?0:n[0]*4,p=o===0?n[0]*4:0,c=ot*s*a*16,d=new Float32Array(c+9*u*a*16),f=bt(t.weight),g=(w,y,b,m)=>w<t.outputChannels&&y<t.inputChannels?f[((w*t.inputChannels+y)*3+b)*3+m]:0;for(let w=0;w<a*4;w++){const y=w>>2,b=w&3;for(let m=0;m<s*4;m++)for(let v=0;v<4;v++)for(let x=0;x<4;x++){let k=0;for(const P of Ei[v>>1][x>>1])for(const T of Ei[v&1][x&1])k+=g(w,l+m,P,T);const B=((v*4+x)*s+(m>>2))*a+y;d[B*16+(m&3)*4+b]=k}for(let m=0;m<u*4;m++)for(let v=0;v<9;v++){const x=(v*u+(m>>2))*a+y;d[c+x*16+(m&3)*4+b]=g(w,p+m,v/3|0,v%3)}}let h;if(i==="fp16"){const w=new Uint16Array(d.length);for(let y=0;y<d.length;y++)w[y]=wr(d[y]);h=new Uint8Array(w.buffer)}else h=new Uint8Array(d.buffer);const _=new Float32Array(a*4);_.set(bt(t.bias));const $=st(r,`oidn/${e}/weights/${i}/subpixel`,h,re.STORAGE);try{return{weights:$,weightLayout:"k-major",bias:st(r,`oidn/${e}/bias`,new Uint8Array(_.buffer),re.STORAGE)}}catch(w){throw $.destroy(),w}}function ro(r,e,t,i,n,o,a,s,u){const l=n.size,p=u?2:1,c=n.componentType,d=n.resultType,f=Fe,g=Ge,h=f+2,_=g+2,$=f/2+2,w=g/2+2,y=l/4,b=a[s],m=a[1-s],v=Math.ceil(b/y),x=Math.ceil(m/y),k=o*l,B=g/2,P=f/2/l,T=Ne*n.subgroupSize,U=L(r),j=L(e),{left:ne,right:ie,load:pe,store:K,multiplyAdd:te,declare:be,extensions:Ue}=kr(n),R=(O,N,q)=>`acc${O}_${N}_${q}`,V=[];for(let O=0;O<B;O++)for(let N=0;N<P;N++)for(let q=0;q<o;q++)V.push(be(R(O,N,q)));const Se=(O,N)=>{const q=[];for(let me=0;me<B;me++)for(let Je=0;Je<P;Je++)q.push(`{
        let a = ${pe(ne,"inputTile",`inputTileBase + ${O(me,Je)}`,N)};
        ${Array.from({length:o},(wa,zt)=>`${R(me,Je,zt)} = ${te}(a, b${zt}, ${R(me,Je,zt)});`).join(`
        `)}
      }`);return q.join(`
      `)},We=O=>Array.from({length:o},(N,q)=>`let b${q} = ${pe(ie,"weightTile",`weightTileBase + ${O} * ${l*k}u + ${q*l}u`,`${k}u`)};`).join(`
      `),De=(O,N,q)=>`(${q} * params.source${O}Width + ${N}) * ${a[O]}u`,Le=Math.max(_*h,w*$)*y,A=ot*l*k/4,Y=(O,N,q)=>({array:"weightTile",vectors:O*l*k/4,stride:A,read:`let quad = i % ${k/4}u;
      let row = i / ${k/4}u;
      let matrix = row / ${l}u;
      let inputChannel = stageChunk * ${l}u + row % ${l}u;
      let outputBlock = blockBase + quad;
      if (inputChannel < ${N*4}u && outputBlock < ${i}u) {
        value = weights[${q}u + ((matrix * ${N}u + inputChannel / 4u) * ${i}u + outputBlock) * 4u + inputChannel % 4u];
      }`}),W=(O,N,q)=>({array:"inputTile",vectors:O*N*y,stride:Le,read:`let pixel = i / ${y}u;
      let block = stageChunk * ${y}u + i % ${y}u;
      ${q}`}),G=`let inputX = i32(tileX / 2u + pixel % ${$}u) - 1;
      let inputY = i32(tileY / 2u + pixel / ${$}u) - 1;
      if (block < ${b}u && inputX >= 0 && inputY >= 0 &&
          inputX < i32(params.source${s}Width) && inputY < i32(params.source${s}Height)) {
        value = input${s}[${De(s,"u32(inputX)","u32(inputY)")} + block];
      }`,Ce=1-s,ke=`let inputX = i32(tileX + pixel % ${h}u) - 1;
      let inputY = i32(tileY + pixel / ${h}u) - 1;
      if (block < ${m}u && inputX >= 0 && inputY >= 0 &&
          inputX < i32(params.outputWidth) && inputY < i32(params.outputHeight)) {
        value = input${Ce}[${De(Ce,"u32(inputX)","u32(inputY)")} + block];
      }`,ge=[];for(let O=0;O<2;O++)for(let N=0;N<2;N++)ge.push(`{
      let matrix = phase * 4u + ${O*2+N}u;
      let offsetY = select(${gt[0][O]+1}u, ${gt[1][O]+1}u, phaseY == 1u);
      let offsetX = select(${gt[0][N]+1}u, ${gt[1][N]+1}u, phaseX == 1u);
      ${We("matrix")}
      ${Se((q,me)=>`((${q}u + offsetY) * ${$}u + ${me*l}u + offsetX) * ${l}u`,`${l}u`)}
    }`);const Qe=`let ky = tap / 3u;
      let kx = tap % 3u;
      ${We("tap")}
      ${Se((O,N)=>`((phaseY + ${O*2}u + ky) * ${h}u + phaseX + kx + ${N*l*2}u) * ${l}u`,`${l*2}u`)}`,Qr=Tr(n,Qe),yi=[];for(let O=0;O<B;O++)for(let N=0;N<o;N++)yi.push(`{
    ${Array.from({length:P},(q,me)=>K("resultTile",`resultBase + ${me*l*l}u`,R(O,me,N),`${l}u`)).join(`
    `)}
    workgroupBarrier();
    let outputY = tileY + phaseY + ${O*2}u;
    for (var e = lane; e < ${f/2*y}u; e += ${n.subgroupSize}u) {
      let pixel = e / ${y}u;
      let outputX = tileX + phaseX + pixel * 2u;
      let outputBlock = blockBase + ${N*y}u + e % ${y}u;
      if (outputX < params.outputWidth && outputY < params.outputHeight && outputBlock < ${i}u) {
        let base = resultBase + pixel * ${l}u + (e % ${y}u) * 4u;
        let acc = vec4<f32>(f32(resultTile[base]), f32(resultTile[base + 1u]),
          f32(resultTile[base + 2u]), f32(resultTile[base + 3u])) + bias[outputBlock];
        outputData[(outputY * params.outputWidth + outputX) * ${i}u + outputBlock] = ${ae(le("acc",t),e)};
      }
    }
    workgroupBarrier();
  }`);return`${r==="fp16"||e==="fp16"||c==="f16"||d==="f16"?`enable f16;
`:""}${Ue}
struct Params {
  outputWidth: u32,
  outputHeight: u32,
  outputBlocks: u32,
  inputBlocks: u32,
  source0Width: u32,
  source0Height: u32,
  source1Width: u32,
  source1Height: u32,
}
@group(0) @binding(0) var<storage, read> input0: array<${U}>;
@group(0) @binding(1) var<storage, read> input1: array<${U}>;
@group(0) @binding(2) var<storage, read> weights: array<${U}>;
@group(0) @binding(3) var<storage, read> bias: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> outputData: array<${j}>;
@group(0) @binding(5) var<uniform> params: Params;

var<workgroup> inputTile: array<${c}, ${p*Le*4}>;
var<workgroup> weightTile: array<${c}, ${p*A*4}>;
var<workgroup> resultTile: array<${d}, ${Ne*(f/2)*l}>;

@compute @workgroup_size(${T})
fn main(
  @builtin(local_invocation_index) localIndex: u32,
  @builtin(workgroup_id) workgroupId: vec3<u32>,
  @builtin(subgroup_id) subgroup: u32,
  @builtin(subgroup_invocation_id) lane: u32
) {
  let tileX = workgroupId.x * ${f}u;
  let tileY = workgroupId.y * ${g}u;
  let blockBase = workgroupId.z * ${k/4}u;
  let phase = subgroup;
  let phaseY = subgroup >> 1u;
  let phaseX = subgroup & 1u;
  let resultBase = subgroup * ${f/2*l}u;
  ${V.join(`
  `)}

  ${Gt(v,[W(w,$,G),Y(ot,b,0)],ge.join(`
    `),T,U,c,u)}

  ${Gt(x,[W(_,h,ke),Y(9,m,ot*b*i*4)],Qr,T,U,c,u)}

  ${yi.join(`
  `)}
}
`}function no(r){return r.op==="concat"?r.inputs:r.op==="fusedUpsampleConcatConv2d"?r.inputs.map(e=>e.value):[r.input]}function oo(r,e="auto"){const t=r.features.has("shader-f16");if(e==="fp16"&&!t)throw new Error("OIDN FP16 was requested but the OIDNGPUDevice does not have shader-f16 enabled");return e==="auto"?t?"fp16":"fp32":e}class ao{_device;usedKernels=new Set;get weightBuffers(){return[...this._packedConvs.values()].flatMap(e=>[e.weights,e.bias])}precision;kernelSetting;gemm;maxSpatialInputBlocks;subgroupsAvailable;subgroupMatrix;subgroupMatrixOutputFragments;subgroupMatrixSubPixel;subgroupMatrixDoubleBuffer;_subgroupMatrixFixedFragments;_model;_gemmByOutputBlocks=new Map;_packedConvs=new Map;_pipelineCache;_executionCache=new Map;_retiredExecutions=new Set;_clock=0;_shapeCacheSize;_profileNextExecution=!1;_profileOperations=0;_resources=new $r;_disposed=!1;constructor(e,t,i={}){this._device=e,this._pipelineCache=An(e),this.precision=oo(e,i.precision??"auto"),this.kernelSetting=i.kernel??"auto";const n=i.gemm?.workgroupSize??[8,8];if(this.gemm=Object.freeze({tilePolicy:i.gemm?.tilePolicy??(i.gemm?.workgroupSize?"fixed":"output-aligned"),decoderLoad:i.gemm?.decoderLoad??"per-load",decoderSubPixel:i.gemm?.decoderSubPixel??this.precision==="fp16",unrollRows:i.gemm?.unrollRows??!1,poolLayout:i.gemm?.poolLayout??"channels",sharedLayout:i.gemm?.sharedLayout??(this.precision==="fp16"?"padded-input":"padded"),accumulationOrder:i.gemm?.accumulationOrder??"k-major",finalLayer:i.gemm?.finalLayer??"shared-auto",loadMode:i.gemm?.loadMode??"native",addressMode:i.gemm?.addressMode??"incremental",weightLayout:i.gemm?.weightLayout??"k-major",rowsPerThread:i.gemm?.rowsPerThread??8,workgroupSize:Object.freeze([n[0],n[1]])}),!["fixed","output-aligned"].includes(this.gemm.tilePolicy))throw new Error(`Unsupported GEMM tile policy: ${this.gemm.tilePolicy}`);if(!["per-load","source-first"].includes(this.gemm.decoderLoad))throw new Error(`Unsupported GEMM decoder load: ${this.gemm.decoderLoad}`);if(!["spatial","channels"].includes(this.gemm.poolLayout))throw new Error(`Unsupported GEMM pool layout: ${this.gemm.poolLayout}`);if(!["linear","padded","padded-input","padded-weights"].includes(this.gemm.sharedLayout))throw new Error(`Unsupported GEMM shared layout: ${this.gemm.sharedLayout}`);if(!["k-major","row-major"].includes(this.gemm.accumulationOrder))throw new Error(`Unsupported GEMM accumulation order: ${this.gemm.accumulationOrder}`);if(!["direct","shared-input","shared-input-weights","shared-auto"].includes(this.gemm.finalLayer))throw new Error(`Unsupported GEMM final layer: ${this.gemm.finalLayer}`);if(!["native","packed-weights","packed-all"].includes(this.gemm.loadMode))throw new Error(`Unsupported GEMM load mode: ${this.gemm.loadMode}`);if(!["analytic","incremental","base-offset"].includes(this.gemm.addressMode))throw new Error(`Unsupported GEMM address mode: ${this.gemm.addressMode}`);if(!["output-major","k-major"].includes(this.gemm.weightLayout))throw new Error(`Unsupported GEMM weight layout: ${this.gemm.weightLayout}`);const o=ce(this.gemm),a=(ve(this.gemm).input+ve(this.gemm).weights)*4*(this.precision==="fp16"?2:4);if(![2,4,8].includes(o.rowsPerThread)||![4,8,16].includes(o.workgroupX)||![4,8].includes(o.workgroupY)||n.length!==2||o.workgroupX>e.limits.maxComputeWorkgroupSizeX||o.workgroupY>e.limits.maxComputeWorkgroupSizeY||o.workgroupX*o.workgroupY>e.limits.maxComputeInvocationsPerWorkgroup||a>e.limits.maxComputeWorkgroupStorageSize)throw new Error("Unsupported GEMM tile configuration for this OIDNGPUDevice");this.subgroupsAvailable=e.features.has("subgroups");const s=i.subgroupMatrix??{},u=this.kernelSetting==="subgroup-matrix"?Qn(e,s.accumulation):void 0;this.subgroupMatrixOutputFragments=u?Jn(u,s):0,this.subgroupMatrixSubPixel=s.subPixel??!0,this._subgroupMatrixFixedFragments=s.outputFragments!==void 0;const l=c=>u!==void 0&&eo(u,this.subgroupMatrixOutputFragments,this.subgroupMatrixSubPixel,c)<=e.limits.maxComputeWorkgroupStorageSize;if(u&&s.outputFragments===void 0&&!l(!1)&&(this.subgroupMatrixOutputFragments=1),this.subgroupMatrixDoubleBuffer=(s.doubleBuffer??!1)&&l(!0),u&&Ne*u.subgroupSize<=e.limits.maxComputeInvocationsPerWorkgroup&&Ne*u.subgroupSize<=e.limits.maxComputeWorkgroupSizeX&&l(this.subgroupMatrixDoubleBuffer)&&(this.subgroupMatrix=u),this.maxSpatialInputBlocks=this.precision==="fp16"&&e.limits.maxComputeInvocationsPerWorkgroup>=H*H&&e.limits.maxComputeWorkgroupSizeX>=H&&e.limits.maxComputeWorkgroupSizeY>=H?Math.floor(e.limits.maxComputeWorkgroupStorageSize/(se*se*4*2)):0,this._shapeCacheSize=Math.max(1,i.shapeCacheSize??2),t.inputChannels%3!==0||t.inputChannels<3||t.inputChannels>9)throw new Error(`Native OIDN expects 3, 6, or 9 input channels, got ${t.inputChannels}`);this._model={spec:t.spec,inputChannels:t.inputChannels,outputChannels:t.outputChannels,channelsByValue:new Map(t.channelsByValue),convChannels:new Map(t.convChannels)};const p=new Map;for(const c of ui(this._model,{fuseConvPool:this._matrixPool()}).nodes){if(c.op==="fusedUpsampleConcatConv2d"){const d=this._subPixelDecoder(c);d&&p.set(c.conv.id,d)}if(c.op!=="conv2d"&&c.op!=="maxPool2d"&&c.op!=="fusedConvReluMaxPool2d"&&c.op!=="fusedUpsampleConcatConv2d")throw new Error(`Native OIDN descriptor ${t.spec.id} leaves unsupported ${c.op} node ${c.id} after graph optimization`)}try{for(const[c,d]of t.convTensors){const f=this._selectConvKernel(M(d.inputChannels),c===t.spec.output),g=f==="implicit-gemm"?this.gemm.weightLayout:f==="subgroup-matrix"?"k-major":"output-major",h=p.get(c),_=h?io(e,c,d,this.precision,h.sourceBlocks,h.upsampledSource):zn(e,c,d,this.precision,g);this._resources.track("gpu-buffer",_.weights),this._resources.track("gpu-buffer",_.bias),this._packedConvs.set(c,_)}}catch(c){for(const d of this._packedConvs.values())this._releaseBuffer(d.weights),this._releaseBuffer(d.bias);throw this._packedConvs.clear(),c}}_pipeline(e,t){let i=this._pipelineCache.get(e);return i||(i=this._device.createComputePipeline({label:`oidn/${e}`,layout:"auto",compute:{module:this._device.createShaderModule({label:`oidn/${e}`,code:t}),entryPoint:"main"}}),this._pipelineCache.set(e,i)),i}_nodePipelineSpec(e,t,i=this.subgroupMatrixOutputFragments){if(e.op==="conv2d"){const n=t?"fp32":this.precision,o=M(this._model.convChannels.get(e.id).inputChannels),a=M(this._model.convChannels.get(e.id).outputChannels),s=this._gemmForOutput(a),u=this._selectConvKernel(o,t),l=s.finalLayer==="shared-input-weights"||s.finalLayer==="shared-auto"&&Bi(this.precision,o,!0)<=this._device.limits.maxComputeWorkgroupStorageSize;return u!=="subgroup-matrix"&&t&&this._model.convChannels.get(e.id).outputChannels===3&&(this.kernelSetting==="auto"||this.kernelSetting==="implicit-gemm"||this.kernelSetting==="subgroup-matrix")&&s.finalLayer!=="direct"&&this._device.limits.maxComputeWorkgroupSizeX>=8&&this._device.limits.maxComputeWorkgroupSizeY>=8&&this._device.limits.maxComputeInvocationsPerWorkgroup>=64&&Bi(this.precision,o,l)<=this._device.limits.maxComputeWorkgroupStorageSize?{key:`conv-final-rgb/${this.precision}/${e.activation}/in${o}/weights-${l?"shared":"storage"}`,kernel:"direct",code:Mn(this.precision,e.activation,o,l)}:u==="subgroup-matrix"?this._subgroupMatrixSpec(`conv/${e.activation}/in${o}/out${a}`,n,e.activation,o,a,i):{key:`conv-${u}/${this.precision}/${n}/${e.activation}/in${o}/out${a}`+(u==="implicit-gemm"?`/address-${s.addressMode}/weights-${s.weightLayout}-v1/tile-${s.workgroupSize.join("x")}-r${s.rowsPerThread}/loads-${s.loadMode}/shared-${s.sharedLayout}/acc-${s.accumulationOrder}/unroll-${Number(s.unrollRows)}`:""),kernel:u,code:u==="implicit-gemm"?Xn(this.precision,n,e.activation,o,a,s):u==="spatial"?Rn(this.precision,n,e.activation,o,a):u==="subgroup"?Ln(this.precision,n,e.activation,o,a):Dn(this.precision,n,e.activation,o,a)}}if(e.op==="maxPool2d"){const n=M(this._model.channelsByValue.get(e.id)),o=this._coalescedPool();return{key:`max-pool/${this.precision}/out${n}/${o?"channels":"spatial"}`,kernel:"direct",code:Fn(this.precision,n,o)}}if(e.op==="fusedConvReluMaxPool2d"){const n=M(this._model.convChannels.get(e.conv.id).inputChannels),o=M(this._model.convChannels.get(e.conv.id).outputChannels);return this._matrixPool()?this._subgroupMatrixSpec(`conv-pool/${e.conv.activation}/in${n}/out${o}`,this.precision,e.conv.activation,n,o,i,void 0,!0):{key:`conv-pool/${this.precision}/${e.conv.activation}/in${n}/out${o}`,kernel:"direct",code:Yn(this.precision,e.conv.activation,n,o)}}if(e.op==="fusedUpsampleConcatConv2d"){if(e.inputs.length!==2)throw new Error(`Native fused decoder ${e.id} requires two inputs`);const n=e.inputs.map(f=>M(this._model.channelsByValue.get(f.value))),o=e.inputs.findIndex(f=>f.upsample);if(o!==0&&o!==1)throw new Error(`Native fused decoder ${e.id} has no upsample input`);const a=n[0]+n[1],s=t?"fp32":this.precision,u=this._selectConvKernel(a,t),l=u==="subgroup"?"direct":u,p=M(this._model.convChannels.get(e.conv.id).outputChannels);if(l==="subgroup-matrix"&&this._subPixelDecoder(e)){const f=this.subgroupMatrix;return{key:`subgroup-matrix-subpixel/${this.precision}/${s}/${f.dialect}/${f.componentType}-${f.resultType}-${f.size}-sg${f.subgroupSize}/n${i}${this.subgroupMatrixDoubleBuffer?"-db":""}/${e.conv.activation}/${n.join("+")}/out${p}/up${o}`,kernel:"subgroup-matrix",code:ro(this.precision,s,e.conv.activation,p,f,i,n,o,this.subgroupMatrixDoubleBuffer)}}if(l==="subgroup-matrix")return this._subgroupMatrixSpec(`decoder/${e.conv.activation}/${n.join("+")}/out${p}/up${o}`,s,e.conv.activation,a,p,i,{sourceBlocks:n,upsampledSource:o});const c=this._gemmForOutput(p);return{key:`decoder-${l}${l==="implicit-gemm"&&this._subPixelDecoder(e)?"-subpixel":""}/${this.precision}/${s}/${e.conv.activation}/${n.join("+")}/out${p}/up${o}`+(l==="implicit-gemm"?`/address-${c.addressMode}/weights-${c.weightLayout}-v1/tile-${c.workgroupSize.join("x")}-r${c.rowsPerThread}/loads-${c.loadMode}/shared-${c.sharedLayout}/acc-${c.accumulationOrder}/unroll-${Number(c.unrollRows)}/decoder-${c.decoderLoad}`:""),kernel:l,code:l==="implicit-gemm"?(this._subPixelDecoder(e)?Hn:Gn)(this.precision,s,e.conv.activation,n,o,p,c):l==="spatial"?jn(this.precision,s,e.conv.activation,n,o,p):Vn(this.precision,s,e.conv.activation,n,o,p)}}throw new Error(`Native OIDN does not implement unfused ${e.op} node ${e.id}`)}_subPixelDecoder(e){if(e.id===this._model.spec.output||e.inputs.length!==2)return;const t=this._selectConvKernel(M(this._model.convChannels.get(e.conv.id).inputChannels),!1);if(!(t==="subgroup-matrix"&&this.subgroupMatrixSubPixel)&&!(t==="implicit-gemm"&&this.gemm.decoderSubPixel&&this.gemm.weightLayout==="k-major"))return;const i=e.inputs[0].upsample?0:e.inputs[1].upsample?1:-1;if(i!==-1)return{sourceBlocks:e.inputs.map(n=>M(this._model.channelsByValue.get(n.value))),upsampledSource:i}}_subgroupMatrixSpec(e,t,i,n,o,a,s,u=!1){const l=this.subgroupMatrix;return{key:`subgroup-matrix/${this.precision}/${t}/${l.dialect}/${l.componentType}-${l.resultType}-${l.size}-sg${l.subgroupSize}/n${a}${this.subgroupMatrixDoubleBuffer?"-db":""}/${e}`,kernel:"subgroup-matrix",code:to(this.precision,t,i,n,o,l,a,this.subgroupMatrixDoubleBuffer,s,u)}}_subgroupMatrixFragmentsFor(e){const t=Math.min(this.subgroupMatrixOutputFragments,Math.ceil(M(e.channels)*4/this.subgroupMatrix.size));return this._subgroupMatrixFixedFragments||t===1?t:Math.ceil(e.width/Fe)*Math.ceil(e.height/Ge)*Math.ceil(M(e.channels)*4/(t*this.subgroupMatrix.size))<Zn?1:t}_gemmForOutput(e){if(this.gemm.tilePolicy!=="output-aligned"||this.gemm.workgroupSize[0]!==8||e<=0||e%16!==0)return this.gemm;const t=this._gemmByOutputBlocks.get(e);if(t)return t;const i=Object.freeze({...this.gemm,workgroupSize:Object.freeze([16,this.gemm.workgroupSize[1]])}),n=ce(i),o=ve(i),a=this._device.limits,u=n.workgroupX<=a.maxComputeWorkgroupSizeX&&n.workgroupY<=a.maxComputeWorkgroupSizeY&&n.workgroupX*n.workgroupY<=a.maxComputeInvocationsPerWorkgroup&&(o.input+o.weights)*4*(this.precision==="fp16"?2:4)<=a.maxComputeWorkgroupStorageSize?i:this.gemm;return this._gemmByOutputBlocks.set(e,u),u}_matrixPool(){const e=this.subgroupMatrix;return this._model.spec.family==="oidn-unet-large"&&this.precision==="fp16"&&e?.dialect==="naga"&&e.size===8&&e.subgroupSize===32&&e.componentType==="f16"&&e.resultType==="f32"}_coalescedPool(){return this.gemm.poolLayout==="channels"&&(this.kernelSetting==="auto"||this.kernelSetting==="implicit-gemm"||this.kernelSetting==="subgroup-matrix")}_selectConvKernel(e,t){const i=this.precision==="fp16"&&e<=this.maxSpatialInputBlocks;return this.kernelSetting==="direct"?"direct":this.kernelSetting==="spatial"?i?"spatial":"direct":this.kernelSetting==="implicit-gemm"?t?"direct":"implicit-gemm":this.kernelSetting==="subgroup"?this.subgroupsAvailable?"subgroup":"direct":this.kernelSetting==="subgroup-matrix"?t?this.subgroupMatrix?.dialect==="naga"?"subgroup-matrix":"direct":this.subgroupMatrix?"subgroup-matrix":"implicit-gemm":t?"direct":"implicit-gemm"}_nodePipeline(e,t){const{key:i,code:n}=this._nodePipelineSpec(e,t);return this._pipeline(i,n)}_createExecution(e,t){const i=this._matrixPool(),n=Pn(this._model,e,t,{fuseConvPool:i}),o=new Map,a=[],s=[],u=new Map;n.nodes.forEach((c,d)=>{for(const f of no(c))u.set(f,d)}),u.set(n.spec.output,n.nodes.length);const l=[],p=c=>(l.push(c),this._resources.track("gpu-buffer",c));try{const c=(m,v,x,k)=>{const B=On(v,x),P=s.filter(U=>U.lastUse<k);let T=P.filter(U=>U.capacity>=B).sort((U,j)=>U.capacity-j.capacity)[0];!T&&i&&(T=P.sort((U,j)=>j.capacity-U.capacity)[0]),T||(T={capacity:0,lastUse:-2,values:[]},s.push(T)),T.capacity=Math.max(T.capacity,B),T.lastUse=u.get(m)??-1,T.values.push(m)};c(n.spec.input,n.inputShape,this.precision==="fp16"?2:4,-1),n.plannedNodes.forEach(({node:m,outputShape:v},x)=>{const k=m.id===n.spec.output;c(m.id,v,k||this.precision==="fp32"?4:2,x)}),s.forEach((m,v)=>{const x=p(this._device.createBuffer({label:`oidn/activation/${e}x${t}/${v}`,size:ci(m.capacity,4),usage:re.STORAGE|re.COPY_SRC|re.COPY_DST}));a.push({buffer:x,capacity:m.capacity});for(const k of m.values)o.set(k,x)});const d=this._model.inputChannels/3,f=`pack/${this.precision}/${d}`,g=this._pipeline(f,br(this.precision,d)),h=[],_=[],$=[],w=[],y=[];n.plannedNodes.forEach(({node:m,outputShape:v},x)=>{const k=m.id===n.spec.output,B=this.subgroupMatrix?this._subgroupMatrixFragmentsFor(v):0,P=this._nodePipelineSpec(m,k,B);P.kernel&&this.usedKernels.add(P.kernel);const T=this._pipeline(P.key,P.code);h.push(T),_.push(P.kernel??"direct"),$.push(P.kernel==="subgroup-matrix"?B:0);const U=o.get(m.id);let j,ne,ie;if(m.op==="conv2d"){const K=n.valueShapes.get(m.input);ie=m.id,ne=[K.width,K.height,v.width,v.height,M(K.channels),M(v.channels)];const te=this._packedConvs.get(ie);j=[{binding:0,resource:{buffer:o.get(m.input)}},{binding:1,resource:{buffer:te.weights}},{binding:2,resource:{buffer:te.bias}},{binding:3,resource:{buffer:U}}]}else if(m.op==="maxPool2d"){const K=n.valueShapes.get(m.input);ne=[K.width,K.height,v.width,v.height,M(v.channels)],j=[{binding:0,resource:{buffer:o.get(m.input)}},{binding:1,resource:{buffer:U}}]}else if(m.op==="fusedConvReluMaxPool2d"){const K=n.valueShapes.get(m.input);ie=m.conv.id,ne=[K.width,K.height,v.width,v.height,M(K.channels),M(v.channels)];const te=this._packedConvs.get(ie);j=[{binding:0,resource:{buffer:o.get(m.input)}},{binding:1,resource:{buffer:te.weights}},{binding:2,resource:{buffer:te.bias}},{binding:3,resource:{buffer:U}}]}else if(m.op==="fusedUpsampleConcatConv2d"){ie=m.conv.id;const K=n.valueShapes.get(m.inputs[0].value),te=n.valueShapes.get(m.inputs[1].value);ne=[v.width,v.height,M(v.channels),M(this._model.convChannels.get(ie).inputChannels),K.width,K.height,te.width,te.height];const be=this._packedConvs.get(ie);j=[{binding:0,resource:{buffer:o.get(m.inputs[0].value)}},{binding:1,resource:{buffer:o.get(m.inputs[1].value)}},{binding:2,resource:{buffer:be.weights}},{binding:3,resource:{buffer:be.bias}},{binding:4,resource:{buffer:U}}]}else throw new Error(`Unexpected native node ${m.op}`);const pe=p(Ci(this._device,`oidn/${m.id}/params/${e}x${t}`,ne));y.push(pe),j.push({binding:j.length,resource:{buffer:pe}}),w.push(this._device.createBindGroup({label:`oidn/${m.id}/bindings`,layout:T.getBindGroupLayout(0),entries:j}))});const b=p(Ci(this._device,`oidn/input/params/${e}x${t}`,[e,t,M(this._model.inputChannels),this._model.inputChannels]));return y.push(b),{plan:n,valueBuffers:o,slots:a,nodeBindings:w,nodePipelines:h,nodeKernels:_,nodeFragments:$,inputPipeline:g,inputUniform:b,ownedBuffers:y,lastUsed:++this._clock}}catch(c){for(const d of l)this._releaseBuffer(d);throw c}}_execution(e,t){if(this._disposed)throw new Error("Native OIDN executor is disposed");const i=`${e}x${t}`;let n=this._executionCache.get(i);if(!n&&(n=this._createExecution(e,t),this._executionCache.set(i,n),this._executionCache.size>this._shapeCacheSize)){const o=[...this._executionCache.entries()].filter(([a])=>a!==i).sort((a,s)=>a[1].lastUsed-s[1].lastUsed)[0];o&&(this._executionCache.delete(o[0]),this._retireExecution(o[1]))}return n.lastUsed=++this._clock,n}_retireExecution(e){this._destroyExecution(e)}prewarm(e){for(const t of e)this._execution(t.width,t.height)}profileNextExecution(){return this._device.features.has("timestamp-query")?(this._profileNextExecution=!0,!0):!1}packedInputBuffer(e,t){const i=this._execution(e,t);return i.valueBuffers.get(i.plan.spec.input)}executePacked(e,t){return this._execute([],e,t,!0)}execute(e,t,i){return this._execute(e,t,i,!1)}_execute(e,t,i,n){const o=this._model.inputChannels/3;if(!n&&e.length!==o)throw new Error(`Native OIDN expected ${o} input buffers, got ${e.length}`);const a=this._execution(t,i),s=[...n?[]:["input-pack"],...a.plan.nodes.map(h=>h.id)],u=this._profileNextExecution&&this._device.features.has("timestamp-query");this._profileNextExecution=!1;const l=s.length*2,p=u?this._resources.track("gpu-query-set",this._device.createQuerySet({type:"timestamp",count:l})):void 0,c=l*8;let d,f;try{d=u?this._resources.track("gpu-buffer",this._device.createBuffer({label:`oidn/profile/resolve/${t}x${i}`,size:c,usage:re.QUERY_RESOLVE|re.COPY_SRC})):void 0,f=u?this._resources.track("gpu-buffer",this._device.createBuffer({label:`oidn/profile/readback/${t}x${i}`,size:c,usage:re.COPY_DST|re.MAP_READ})):void 0}catch(h){throw this._releaseBuffer(f),this._releaseBuffer(d),this._releaseQuerySet(p),h}const g=(h,_)=>({label:h,...p?{timestampWrites:{querySet:p,beginningOfPassWriteIndex:_*2,endOfPassWriteIndex:_*2+1}}:{}});try{const h=this._device.createCommandEncoder({label:`oidn/native/${t}x${i}`});if(!n){const _=e.map((y,b)=>({binding:b,resource:{buffer:y}}));_.push({binding:o,resource:{buffer:a.valueBuffers.get(a.plan.spec.input)}}),_.push({binding:o+1,resource:{buffer:a.inputUniform}});const $=this._device.createBindGroup({label:"oidn/input/bindings",layout:a.inputPipeline.getBindGroupLayout(0),entries:_}),w=h.beginComputePass(g("oidn/input-pack",0));w.setPipeline(a.inputPipeline),w.setBindGroup(0,$),w.dispatchWorkgroups(Math.ceil(t/Q),Math.ceil(i/Q),M(this._model.inputChannels)),w.end()}a.plan.plannedNodes.forEach(({node:_,outputShape:$},w)=>{const y=h.beginComputePass(g(`oidn/${a.plan.nodes[w].id}`,w+(n?0:1)));if(y.setPipeline(a.nodePipelines[w]),y.setBindGroup(0,a.nodeBindings[w]),_.op==="maxPool2d"&&this._coalescedPool()){const b=Math.ceil($.width*M($.channels)/Q),m=this._device.limits.maxComputeWorkgroupsPerDimension;y.dispatchWorkgroups(Math.min(b,m),Math.ceil($.height/Q),Math.ceil(b/m))}else if(a.nodeKernels[w]==="subgroup-matrix")y.dispatchWorkgroups(Math.ceil($.width*(_.op==="fusedConvReluMaxPool2d"?2:1)/Fe),Math.ceil($.height*(_.op==="fusedConvReluMaxPool2d"?2:1)/Ge),Math.ceil(M($.channels)/(a.nodeFragments[w]*this.subgroupMatrix.size/4)));else if(a.nodeKernels[w]==="implicit-gemm"){const b=ce(this._gemmForOutput(M($.channels))),m=_.op==="fusedUpsampleConcatConv2d"&&this._subPixelDecoder(_)!==void 0;y.dispatchWorkgroups(Math.ceil((m?Math.ceil($.width/2)*Math.ceil($.height/2):$.width*$.height)/b.tileM),Math.ceil(M($.channels)/b.tileNBlocks),m?4:1)}else y.dispatchWorkgroups(Math.ceil($.width/Q),Math.ceil($.height/Q),M($.channels));y.end()}),p&&(h.resolveQuerySet(p,0,l,d,0),h.copyBufferToBuffer(d,0,f,0,c)),this._device.queue.submit([h.finish()])}catch(h){throw this._releaseBuffer(f),this._releaseBuffer(d),this._releaseQuerySet(p),h}return p&&(this._profileOperations++,this._readProfile(p,d,f,s)),a.valueBuffers.get(a.plan.spec.output)}_readProfile(e,t,i,n){this._releaseQuerySet(e),this._releaseBuffer(t),this._releaseBuffer(i),this._profileOperations--}_releaseBuffer(e){this._resources.release("gpu-buffer",e,()=>e.destroy())}_releaseQuerySet(e){this._resources.release("gpu-query-set",e,()=>e.destroy())}_destroyExecution(e){e.slots.forEach(t=>this._releaseBuffer(t.buffer)),e.ownedBuffers.forEach(t=>this._releaseBuffer(t))}getResourceInfo(){return this._resources.snapshot(this._retiredExecutions.size+this._profileOperations)}dispose(){if(!this._disposed){this._disposed=!0;for(const e of this._packedConvs.values())this._releaseBuffer(e.weights),this._releaseBuffer(e.bias);this._packedConvs.clear();for(const e of this._executionCache.values())this._destroyExecution(e);this._executionCache.clear();for(const e of this._retiredExecutions)this._destroyExecution(e);this._retiredExecutions.clear()}}}const Mi=new WeakMap;class uo extends ao{_lastExecutionProfile;constructor(e,t,i){super(e,t,i)}execute(e,t,i){return super.execute(e,t,i)}get _asyncDevice(){return this._device}get _pipelinePromises(){let e=Mi.get(this._device);return e||(e=new Map,Mi.set(this._device,e)),e}getLastExecutionProfile(){return this._lastExecutionProfile}_pipelineAsync(e,t){const i=this._pipelineCache.get(e);if(i)return Promise.resolve(i);const n=this._pipelinePromises.get(e);if(n)return n;const o=this._asyncDevice.createComputePipelineAsync({label:`oidn/${e}`,layout:"auto",compute:{module:this._device.createShaderModule({label:`oidn/${e}`,code:t}),entryPoint:"main"}}).then(a=>(this._pipelineCache.set(e,a),this._pipelinePromises.delete(e),a),a=>{throw this._pipelinePromises.delete(e),a});return this._pipelinePromises.set(e,o),o}_retireExecution(e){this._retiredExecutions.add(e),this._asyncDevice.queue.onSubmittedWorkDone().catch(()=>{}).then(()=>{this._retiredExecutions.delete(e),this._destroyExecution(e)})}async prepare(){if(this._disposed)throw new Error("Native OIDN executor is disposed");const e=ui(this._model,{fuseConvPool:!1}),t=this._model.inputChannels/3,i=[{key:`pack/${this.precision}/${t}`,code:br(this.precision,t)},...e.nodes.map(n=>this._nodePipelineSpec(n,n.id===e.spec.output))];await Promise.all(i.map(({key:n,code:o})=>this._pipelineAsync(n,o)))}_readProfile(e,t,i,n){this._lastExecutionProfile=(async()=>{try{await i.mapAsync(Ii.READ);const o=new Uint32Array(i.getMappedRange()),a=u=>o[u*2+1]*4294967296+o[u*2],s=n.map((u,l)=>({id:u,durationMs:(a(l*2+1)-a(l*2))/1e6}));return{totalMs:s.reduce((u,l)=>u+l.durationMs,0),layers:s}}finally{i.mapState==="mapped"&&i.unmap(),this._releaseQuerySet(e),this._releaseBuffer(t),this._releaseBuffer(i),this._profileOperations--}})()}async executeCPU(e,t,i){const n=t*i*this._model.inputChannels;if(e.length!==n)throw new Error(`Native OIDN CPU input has ${e.length} values, expected ${n}`);const o=this._execution(t,i),a=this._model.inputChannels/3,s=t*i;o.cpuInputBuffers||(o.cpuInputBuffers=Array.from({length:a},(d,f)=>{const g=this._device.createBuffer({label:`oidn/cpu-input/${t}x${i}/${f}`,size:s*16,usage:re.STORAGE|re.COPY_DST});return this._resources.track("gpu-buffer",g),o.ownedBuffers.push(g),g}),o.cpuReadbackBuffer=this._device.createBuffer({label:`oidn/cpu-readback/${t}x${i}`,size:s*16,usage:re.COPY_DST|re.MAP_READ}),this._resources.track("gpu-buffer",o.cpuReadbackBuffer),o.ownedBuffers.push(o.cpuReadbackBuffer));for(let d=0;d<a;d++){const f=new Float32Array(s*4);for(let g=0;g<s;g++){const h=g*this._model.inputChannels+d*3,_=g*4;f[_]=e[h],f[_+1]=e[h+1],f[_+2]=e[h+2]}this._device.queue.writeBuffer(o.cpuInputBuffers[d],0,new Uint8Array(f.buffer,f.byteOffset,f.byteLength))}const u=super.execute(o.cpuInputBuffers,t,i),l=this._device.createCommandEncoder({label:`oidn/cpu-readback/${t}x${i}`});l.copyBufferToBuffer(u,0,o.cpuReadbackBuffer,0,s*16),this._device.queue.submit([l.finish()]),await o.cpuReadbackBuffer.mapAsync(Ii.READ);const p=new Float32Array(o.cpuReadbackBuffer.getMappedRange()),c=new Float32Array(s*3);for(let d=0;d<s;d++)c[d*3]=p[d*4],c[d*3+1]=p[d*4+1],c[d*3+2]=p[d*4+2];return o.cpuReadbackBuffer.unmap(),c}}const so="This is not an object",co="This is not a Float16Array object",Ai="This constructor is not a subclass of Float16Array",Ir="The constructor property value is not an object",lo="Species constructor didn't return TypedArray object",po="Derived constructor created TypedArray object which was too small length",at="Attempting to access detached ArrayBuffer",Ht="Cannot convert undefined or null to object",Vt="Cannot mix BigInt and other types, use explicit conversions",Oi="@@iterator property is not callable",Ni="Reduce of empty array with no initial value",ho="The comparison function must be either a function or undefined",Dt="Offset is out of bounds";function X(r){return(e,...t)=>oe(r,e,t)}function qe(r,e){return X(He(r,e).get)}const{apply:oe,construct:it,defineProperty:zi,get:Lt,getOwnPropertyDescriptor:He,getPrototypeOf:lt,has:jt,ownKeys:Br,set:Ui,setPrototypeOf:Pr}=Reflect,fo=Proxy,{EPSILON:go,MAX_SAFE_INTEGER:Wi,isFinite:Sr,isNaN:Ve}=Number,{iterator:ye,species:mo,toStringTag:pi,for:$o}=Symbol,je=Object,{create:Et,defineProperty:pt,freeze:_o,is:Di}=je,Kt=je.prototype,yo=Kt.__lookupGetter__?X(Kt.__lookupGetter__):(r,e)=>{if(r==null)throw F(Ht);let t=je(r);do{const i=He(t,e);if(i!==void 0)return xe(i,"get")?i.get:void 0}while((t=lt(t))!==null)},xe=je.hasOwn||X(Kt.hasOwnProperty),Cr=Array,Er=Cr.isArray,Mt=Cr.prototype,wo=X(Mt.join),xo=X(Mt.push),vo=X(Mt.toLocaleString),di=Mt[ye],bo=X(di),{abs:ko,trunc:Mr}=Math,At=ArrayBuffer,To=At.isView,Ar=At.prototype,Io=X(Ar.slice),Bo=qe(Ar,"byteLength"),qt=typeof SharedArrayBuffer<"u"?SharedArrayBuffer:null,Po=qt&&qe(qt.prototype,"byteLength"),hi=lt(Uint8Array),So=hi.from,ee=hi.prototype,Co=ee[ye],Eo=X(ee.keys),Mo=X(ee.values),Ao=X(ee.entries),Oo=X(ee.set),Li=X(ee.reverse),No=X(ee.fill),zo=X(ee.copyWithin),Ri=X(ee.sort),tt=X(ee.slice),Uo=X(ee.subarray),J=qe(ee,"buffer"),Ee=qe(ee,"byteOffset"),E=qe(ee,"length"),Or=qe(ee,pi),Wo=Uint8Array,ue=Uint16Array,Xi=(...r)=>oe(So,ue,r),fi=Uint32Array,Do=Float32Array,ze=lt([][ye]()),Ot=X(ze.next),Lo=X(function*(){}().next),Ro=lt(ze),F=TypeError,Rt=RangeError,Nr=WeakSet,zr=Nr.prototype,Xo=X(zr.add),Yo=X(zr.has),Nt=WeakMap,gi=Nt.prototype,kt=X(gi.get),Fo=X(gi.has),mi=X(gi.set),Ur=new Nt,Go=Et(null,{next:{value:function(){const e=kt(Ur,this);return Ot(e)}},[ye]:{value:function(){return this}}});function mt(r){if(r[ye]===di&&ze.next===Ot)return r;const e=Et(Go);return mi(Ur,e,bo(r)),e}const Wr=new Nt,Dr=Et(Ro,{next:{value:function(){const e=kt(Wr,this);return Lo(e)},writable:!0,configurable:!0}});for(const r of Br(ze))r!=="next"&&pt(Dr,r,He(ze,r));function Yi(r){const e=Et(Dr);return mi(Wr,e,r),e}function Tt(r){return r!==null&&typeof r=="object"||typeof r=="function"}function Fi(r){return r!==null&&typeof r=="object"}function It(r){return Or(r)!==void 0}function Zt(r){const e=Or(r);return e==="BigInt64Array"||e==="BigUint64Array"}function Ho(r){try{return Er(r)?!1:(Bo(r),!0)}catch{return!1}}function Lr(r){if(qt===null)return!1;try{return Po(r),!0}catch{return!1}}function Vo(r){return Ho(r)||Lr(r)}function Gi(r){return Er(r)?r[ye]===di&&ze.next===Ot:!1}function jo(r){return It(r)?r[ye]===Co&&ze.next===Ot:!1}function $t(r){if(typeof r!="string")return!1;const e=+r;return r!==e+""||!Sr(e)?!1:e===Mr(e)}const Bt=$o("__Float16Array__");function Ko(r){if(!Fi(r))return!1;const e=lt(r);if(!Fi(e))return!1;const t=e.constructor;if(t===void 0)return!1;if(!Tt(t))throw F(Ir);return jt(t,Bt)}const Qt=1/go;function qo(r){return r+Qt-Qt}const Rr=6103515625e-14,Zo=65504,Xr=.0009765625,Hi=Xr*Rr,Qo=Xr*Qt;function Jo(r){const e=+r;if(!Sr(e)||e===0)return e;const t=e>0?1:-1,i=ko(e);if(i<Rr)return t*qo(i/Hi)*Hi;const n=(1+Qo)*i,o=n-(n-i);return o>Zo||Ve(o)?t*(1/0):t*o}const Yr=new At(4),Fr=new Do(Yr),Gr=new fi(Yr),de=new ue(512),he=new Wo(512);for(let r=0;r<256;++r){const e=r-127;e<-24?(de[r]=0,de[r|256]=32768,he[r]=24,he[r|256]=24):e<-14?(de[r]=1024>>-e-14,de[r|256]=1024>>-e-14|32768,he[r]=-e-1,he[r|256]=-e-1):e<=15?(de[r]=e+15<<10,de[r|256]=e+15<<10|32768,he[r]=13,he[r|256]=13):e<128?(de[r]=31744,de[r|256]=64512,he[r]=24,he[r|256]=24):(de[r]=31744,de[r|256]=64512,he[r]=13,he[r|256]=13)}function _e(r){Fr[0]=Jo(r);const e=Gr[0],t=e>>23&511;return de[t]+((e&8388607)>>he[t])}const $i=new fi(2048);for(let r=1;r<1024;++r){let e=r<<13,t=0;for(;!(e&8388608);)e<<=1,t-=8388608;e&=-8388609,t+=947912704,$i[r]=e|t}for(let r=1024;r<2048;++r)$i[r]=939524096+(r-1024<<13);const Ze=new fi(64);for(let r=1;r<31;++r)Ze[r]=r<<23;Ze[31]=1199570944;Ze[32]=2147483648;for(let r=33;r<63;++r)Ze[r]=2147483648+(r-32<<23);Ze[63]=3347054592;const Hr=new ue(64);for(let r=1;r<64;++r)r!==32&&(Hr[r]=1024);function z(r){const e=r>>10;return Gr[0]=$i[Hr[e]+(r&1023)]+Ze[e],Fr[0]}function we(r){const e=+r;return Ve(e)||e===0?0:Mr(e)}function Xt(r){const e=we(r);return e<0?0:e<Wi?e:Wi}function _t(r,e){if(!Tt(r))throw F(so);const t=r.constructor;if(t===void 0)return e;if(!Tt(t))throw F(Ir);const i=t[mo];return i??e}function ut(r){if(Lr(r))return!1;try{return Io(r,0,0),!1}catch{}return!0}function Vi(r,e){const t=Ve(r),i=Ve(e);if(t&&i)return 0;if(t)return 1;if(i||r<e)return-1;if(r>e)return 1;if(r===0&&e===0){const n=Di(r,0),o=Di(e,0);if(!n&&o)return-1;if(n&&!o)return 1}return 0}const _i=2,Pt=new Nt;function Xe(r){return Fo(Pt,r)||!To(r)&&Ko(r)}function C(r){if(!Xe(r))throw F(co)}function yt(r,e){const t=Xe(r),i=It(r);if(!t&&!i)throw F(lo);if(typeof e=="number"){let n;if(t){const o=I(r);n=E(o)}else n=E(r);if(n<e)throw F(po)}if(Zt(r))throw F(Vt)}function I(r){const e=kt(Pt,r);if(e!==void 0){const n=J(e);if(ut(n))throw F(at);return e}const t=r.buffer;if(ut(t))throw F(at);const i=it(D,[t,r.byteOffset,r.length],r.constructor);return kt(Pt,i)}function ji(r){const e=E(r),t=[];for(let i=0;i<e;++i)t[i]=z(r[i]);return t}const Vr=new Nr;for(const r of Br(ee)){if(r===pi)continue;const e=He(ee,r);xe(e,"get")&&typeof e.get=="function"&&Xo(Vr,e.get)}const ea=_o({get(r,e,t){return $t(e)&&xe(r,e)?z(Lt(r,e)):Yo(Vr,yo(r,e))?Lt(r,e):Lt(r,e,t)},set(r,e,t,i){return $t(e)&&xe(r,e)?Ui(r,e,_e(t)):Ui(r,e,t,i)},getOwnPropertyDescriptor(r,e){if($t(e)&&xe(r,e)){const t=He(r,e);return t.value=z(t.value),t}return He(r,e)},defineProperty(r,e,t){return $t(e)&&xe(r,e)&&xe(t,"value")&&(t.value=_e(t.value)),zi(r,e,t)}});class D{constructor(e,t,i){let n;if(Xe(e))n=it(ue,[I(e)],new.target);else if(Tt(e)&&!Vo(e)){let a,s;if(It(e)){a=e,s=E(e);const u=J(e);if(ut(u))throw F(at);if(Zt(e))throw F(Vt);const l=new At(s*_i);n=it(ue,[l],new.target)}else{const u=e[ye];if(u!=null&&typeof u!="function")throw F(Oi);u!=null?Gi(e)?(a=e,s=e.length):(a=[...e],s=a.length):(a=e,s=Xt(a.length)),n=it(ue,[s],new.target)}for(let u=0;u<s;++u)n[u]=_e(a[u])}else n=it(ue,arguments,new.target);const o=new fo(n,ea);return mi(Pt,o,n),o}static from(e,...t){const i=this;if(!jt(i,Bt))throw F(Ai);if(i===D){if(Xe(e)&&t.length===0){const p=I(e),c=new ue(J(p),Ee(p),E(p));return new D(J(tt(c)))}if(t.length===0)return new D(J(Xi(e,_e)));const u=t[0],l=t[1];return new D(J(Xi(e,function(p,...c){return _e(oe(u,this,[p,...mt(c)]))},l)))}let n,o;const a=e[ye];if(a!=null&&typeof a!="function")throw F(Oi);if(a!=null)Gi(e)?(n=e,o=e.length):jo(e)?(n=e,o=E(e)):(n=[...e],o=n.length);else{if(e==null)throw F(Ht);n=je(e),o=Xt(n.length)}const s=new i(o);if(t.length===0)for(let u=0;u<o;++u)s[u]=n[u];else{const u=t[0],l=t[1];for(let p=0;p<o;++p)s[p]=oe(u,l,[n[p],p])}return s}static of(...e){const t=this;if(!jt(t,Bt))throw F(Ai);const i=e.length;if(t===D){const o=new D(i),a=I(o);for(let s=0;s<i;++s)a[s]=_e(e[s]);return o}const n=new t(i);for(let o=0;o<i;++o)n[o]=e[o];return n}keys(){C(this);const e=I(this);return Eo(e)}values(){C(this);const e=I(this);return Yi(function*(){for(const t of Mo(e))yield z(t)}())}entries(){C(this);const e=I(this);return Yi(function*(){for(const[t,i]of Ao(e))yield[t,z(i)]}())}at(e){C(this);const t=I(this),i=E(t),n=we(e),o=n>=0?n:i+n;if(!(o<0||o>=i))return z(t[o])}with(e,t){C(this);const i=I(this),n=E(i),o=we(e),a=o>=0?o:n+o,s=+t;if(a<0||a>=n)throw Rt(Dt);const u=new ue(J(i),Ee(i),E(i)),l=new D(J(tt(u))),p=I(l);return p[a]=_e(s),l}map(e,...t){C(this);const i=I(this),n=E(i),o=t[0],a=_t(i,D);if(a===D){const u=new D(n),l=I(u);for(let p=0;p<n;++p){const c=z(i[p]);l[p]=_e(oe(e,o,[c,p,this]))}return u}const s=new a(n);yt(s,n);for(let u=0;u<n;++u){const l=z(i[u]);s[u]=oe(e,o,[l,u,this])}return s}filter(e,...t){C(this);const i=I(this),n=E(i),o=t[0],a=[];for(let l=0;l<n;++l){const p=z(i[l]);oe(e,o,[p,l,this])&&xo(a,p)}const s=_t(i,D),u=new s(a);return yt(u),u}reduce(e,...t){C(this);const i=I(this),n=E(i);if(n===0&&t.length===0)throw F(Ni);let o,a;t.length===0?(o=z(i[0]),a=1):(o=t[0],a=0);for(let s=a;s<n;++s)o=e(o,z(i[s]),s,this);return o}reduceRight(e,...t){C(this);const i=I(this),n=E(i);if(n===0&&t.length===0)throw F(Ni);let o,a;t.length===0?(o=z(i[n-1]),a=n-2):(o=t[0],a=n-1);for(let s=a;s>=0;--s)o=e(o,z(i[s]),s,this);return o}forEach(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=0;a<n;++a)oe(e,o,[z(i[a]),a,this])}find(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=0;a<n;++a){const s=z(i[a]);if(oe(e,o,[s,a,this]))return s}}findIndex(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=0;a<n;++a){const s=z(i[a]);if(oe(e,o,[s,a,this]))return a}return-1}findLast(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=n-1;a>=0;--a){const s=z(i[a]);if(oe(e,o,[s,a,this]))return s}}findLastIndex(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=n-1;a>=0;--a){const s=z(i[a]);if(oe(e,o,[s,a,this]))return a}return-1}every(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=0;a<n;++a)if(!oe(e,o,[z(i[a]),a,this]))return!1;return!0}some(e,...t){C(this);const i=I(this),n=E(i),o=t[0];for(let a=0;a<n;++a)if(oe(e,o,[z(i[a]),a,this]))return!0;return!1}set(e,...t){C(this);const i=I(this),n=we(t[0]);if(n<0)throw Rt(Dt);if(e==null)throw F(Ht);if(Zt(e))throw F(Vt);if(Xe(e))return Oo(I(this),I(e),n);if(It(e)){const u=J(e);if(ut(u))throw F(at)}const o=E(i),a=je(e),s=Xt(a.length);if(n===1/0||s+n>o)throw Rt(Dt);for(let u=0;u<s;++u)i[u+n]=_e(a[u])}reverse(){C(this);const e=I(this);return Li(e),this}toReversed(){C(this);const e=I(this),t=new ue(J(e),Ee(e),E(e)),i=new D(J(tt(t))),n=I(i);return Li(n),i}fill(e,...t){C(this);const i=I(this);return No(i,_e(e),...mt(t)),this}copyWithin(e,t,...i){C(this);const n=I(this);return zo(n,e,t,...mt(i)),this}sort(e){C(this);const t=I(this),i=e!==void 0?e:Vi;return Ri(t,(n,o)=>i(z(n),z(o))),this}toSorted(e){C(this);const t=I(this);if(e!==void 0&&typeof e!="function")throw new F(ho);const i=e!==void 0?e:Vi,n=new ue(J(t),Ee(t),E(t)),o=new D(J(tt(n))),a=I(o);return Ri(a,(s,u)=>i(z(s),z(u))),o}slice(e,t){C(this);const i=I(this),n=_t(i,D);if(n===D){const g=new ue(J(i),Ee(i),E(i));return new D(J(tt(g,e,t)))}const o=E(i),a=we(e),s=t===void 0?o:we(t);let u;a===-1/0?u=0:a<0?u=o+a>0?o+a:0:u=o<a?o:a;let l;s===-1/0?l=0:s<0?l=o+s>0?o+s:0:l=o<s?o:s;const p=l-u>0?l-u:0,c=new n(p);if(yt(c,p),p===0)return c;const d=J(i);if(ut(d))throw F(at);let f=0;for(;u<l;)c[f]=z(i[u]),++u,++f;return c}subarray(e,t){C(this);const i=I(this),n=_t(i,D),o=new ue(J(i),Ee(i),E(i)),a=Uo(o,e,t),s=new n(J(a),Ee(a),E(a));return yt(s),s}indexOf(e,...t){C(this);const i=I(this),n=E(i);let o=we(t[0]);if(o===1/0)return-1;o<0&&(o+=n,o<0&&(o=0));for(let a=o;a<n;++a)if(xe(i,a)&&z(i[a])===e)return a;return-1}lastIndexOf(e,...t){C(this);const i=I(this),n=E(i);let o=t.length>=1?we(t[0]):n-1;if(o===-1/0)return-1;o>=0?o=o<n-1?o:n-1:o+=n;for(let a=o;a>=0;--a)if(xe(i,a)&&z(i[a])===e)return a;return-1}includes(e,...t){C(this);const i=I(this),n=E(i);let o=we(t[0]);if(o===1/0)return!1;o<0&&(o+=n,o<0&&(o=0));const a=Ve(e);for(let s=o;s<n;++s){const u=z(i[s]);if(a&&Ve(u)||u===e)return!0}return!1}join(e){C(this);const t=I(this),i=ji(t);return wo(i,e)}toLocaleString(...e){C(this);const t=I(this),i=ji(t);return vo(i,...mt(e))}get[pi](){if(Xe(this))return"Float16Array"}}pt(D,"BYTES_PER_ELEMENT",{value:_i});pt(D,Bt,{});Pr(D,hi);const St=D.prototype;pt(St,"BYTES_PER_ELEMENT",{value:_i});pt(St,ye,{value:St.values,writable:!0,configurable:!0});Pr(St,ee);const Ki=new WeakMap;function ta(r,e){let t=Ki.get(r);t||(t=new Map,Ki.set(r,t));let i=t.get(e);if(!i){const n=r.createShaderModule({label:`oidn/webnn/input-pack/${e}`,code:na(e)}),o=r.createShaderModule({label:"oidn/webnn/output-unpack",code:oa()});i={input:r.createComputePipeline({label:`oidn/webnn/input-pack/${e}`,layout:"auto",compute:{module:n,entryPoint:"main"}}),output:r.createComputePipeline({label:"oidn/webnn/output-unpack",layout:"auto",compute:{module:o,entryPoint:"main"}})},t.set(e,i)}return i}const Pe=8;function jr(r,e){return Math.ceil(r/e)*e}function ia(r,e,t,i){const n=r.createBuffer({label:e,size:jr(t.byteLength,4),usage:i,mappedAtCreation:!0});return new Uint8Array(n.getMappedRange()).set(new Uint8Array(t.buffer,t.byteOffset,t.byteLength)),n.unmap(),n}function qi(r,e,t){const i=new Uint32Array(jr(t.length,4));return i.set(t),ia(r,e,i,GPUBufferUsage.UNIFORM)}function Yt(r,e,t,i){return!!r?.[e]?.[t]?.dataTypes?.includes?.(i)}function ra(r,e){if(e==="fp16"&&r.desc.dataType==="Float16")return new Uint8Array(r.data.buffer,r.data.byteOffset,r.data.byteLength);if(e==="fp32"&&r.desc.dataType==="Float32")return new Uint8Array(r.data.buffer,r.data.byteOffset,r.data.byteLength);const t=r.desc.dataType==="Float32"?new Float32Array(r.data.buffer,r.data.byteOffset,r.data.byteLength/4):new D(r.data.buffer,r.data.byteOffset,r.data.byteLength/2),i=e==="fp16"?new D(t):new Float32Array(t);return new Uint8Array(i.buffer,i.byteOffset,i.byteLength)}function na(r){const e=Array.from({length:r},(i,n)=>`@group(0) @binding(${n}) var<storage, read> input${n}: array<vec4<f32>>;`).join(`
`),t=Array.from({length:r},(i,n)=>{const o=n*3;return`if (channel < ${o+3}u) {
      return input${n}[pixel][channel - ${o}u];
    }`}).join(`
  `);return`enable f16;
struct Params { width: u32, height: u32, channels: u32, padding: u32 }
${e}
@group(0) @binding(${r}) var<storage, read_write> outputData: array<f16>;
@group(0) @binding(${r+1}) var<uniform> params: Params;

fn readChannel(pixel: u32, channel: u32) -> f32 {
  ${t}
  return 0.0;
}

@compute @workgroup_size(${Pe}, ${Pe}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.width || gid.y >= params.height || gid.z >= params.channels) {
    return;
  }
  let pixel = gid.y * params.width + gid.x;
  let outputIndex = (gid.z * params.height + gid.y) * params.width + gid.x;
  outputData[outputIndex] = f16(readChannel(pixel, gid.z));
}
`}function oa(){return`enable f16;
struct Params { width: u32, height: u32, padding0: u32, padding1: u32 }
@group(0) @binding(0) var<storage, read> inputData: array<f16>;
@group(0) @binding(1) var<storage, read_write> outputData: array<vec4<f32>>;
@group(0) @binding(2) var<uniform> params: Params;

@compute @workgroup_size(${Pe}, ${Pe}, 1)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= params.width || gid.y >= params.height) { return; }
  let pixel = gid.y * params.width + gid.x;
  let plane = params.width * params.height;
  outputData[pixel] = vec4<f32>(
    f32(inputData[pixel]),
    f32(inputData[plane + pixel]),
    f32(inputData[plane * 2u + pixel]),
    0.0
  );
}
`}function aa(r,e){if(e==="fp32")throw new Error("OIDN WebNN GPU interop currently requires FP16 exportable tensors");if(!r.features.has("shader-f16"))throw new Error("OIDN WebNN requires shader-f16 on the shared GPUDevice");return"fp16"}function ua(r,e,t){return t==="relu"?r.relu(e):e}class sa{_device;_model;precision;support;_context;_builderConstructor;_shapeCache=new Map;_shapePromises=new Map;_retiredExecutions=new Set;_pendingCreationCount=0;_shapeCacheSize;_clock=0;_inputPipeline;_outputPipeline;_resources=new $r;_disposed=!1;constructor(e,t,i={}){this._device=e,this._model=t,this.precision=aa(e,i.precision??"auto"),this._shapeCacheSize=Math.max(1,i.shapeCacheSize??2),this.support={available:!1,fp16Conv:!1,gpuInterop:!1};const n=ta(e,t.inputChannels/3);this._inputPipeline=n.input,this._outputPipeline=n.output}async prepare(){if(this._disposed)throw new Error("OIDN WebNN executor is disposed");const e=globalThis.navigator?.ml,t=globalThis.MLGraphBuilder;if(!e?.createContext||typeof t!="function")throw this.support.reason="WebNN is not exposed by this browser",new Error(this.support.reason);this._builderConstructor=t;try{try{this._context=await e.createContext({deviceType:"gpu",powerPreference:"high-performance"})}catch{this._context=await e.createContext({deviceType:"gpu"})}if(this._resources.track("ml-context",this._context),this._disposed)throw new Error("OIDN WebNN executor is disposed");if(typeof this._context.createExportableTensor!="function"||typeof this._context.exportToGPU!="function")throw this.support.reason="WebNN WebGPU tensor interop is unavailable",new Error(this.support.reason);const i=this._context.opSupportLimits?.()??{};if(this.support.fp16Conv=Yt(i,"conv2d","input","float16")&&Yt(i,"conv2d","filter","float16")&&Yt(i,"conv2d","output","float16"),!this.support.fp16Conv)throw this.support.reason="WebNN does not support FP16 conv2d",new Error(this.support.reason);let n,o;try{n=this._resources.track("ml-tensor",await this._context.createExportableTensor({dataType:"float16",shape:[4]},this._device)),o=this._resources.track("gpu-buffer",await this._context.exportToGPU(n)),this.support.gpuInterop=!0}catch(a){throw this.support.reason=`WebNN FP16 WebGPU interop failed: ${String(a)}`,new Error(this.support.reason)}finally{this._releaseBuffer(o),this._releaseTensor(n)}this.support.available=!0}catch(i){throw this._releaseContext(),i}}_constant(e,t){return e.constant({dataType:"float16",shape:[...t.desc.dims]},ra(t,this.precision))}async _createExecution(e,t){if(this._disposed)throw new Error("OIDN WebNN executor is disposed");const i=new this._builderConstructor(this._context),n=new Map,o=new Map;n.set(this._model.spec.input,i.input("input",{dataType:"float16",shape:[1,this._model.inputChannels,t,e]})),o.set(this._model.spec.input,[this._model.inputChannels,t,e]);for(const d of this._model.spec.nodes){let f,g;if(d.op==="conv2d"){const h=o.get(d.input),_=this._model.convTensors.get(d.id),$=i.conv2d(n.get(d.input),this._constant(i,_.weight),{bias:this._constant(i,_.bias),padding:[1,1,1,1],inputLayout:"nchw",filterLayout:"oihw"});f=ua(i,$,d.activation),g=[_.outputChannels,h[1],h[2]]}else if(d.op==="maxPool2d"){const h=o.get(d.input);f=i.maxPool2d(n.get(d.input),{windowDimensions:[2,2],strides:[2,2],padding:[0,h[1]%2,0,h[2]%2],layout:"nchw"}),g=[h[0],Math.ceil(h[1]/2),Math.ceil(h[2]/2)]}else if(d.op==="upsample2d"){const h=o.get(d.input);f=i.resample2d(n.get(d.input),{mode:"nearest-neighbor",axes:[2,3],scales:[2,2]}),g=[h[0],h[1]*2,h[2]*2]}else{const h=d.inputs.map(_=>o.get(_));if(h.some(_=>_[1]!==h[0][1]||_[2]!==h[0][2]))throw new Error(`WebNN concat ${d.id} has mismatched spatial shapes`);f=i.concat(d.inputs.map(_=>n.get(_)),1),g=[h.reduce((_,$)=>_+$[0],0),h[0][1],h[0][2]]}n.set(d.id,f),o.set(d.id,g)}let a,s,u,l,p,c;try{return a=this._resources.track("ml-graph",await i.build({output:n.get(this._model.spec.output)})),s=this._resources.track("ml-tensor",await this._context.createExportableTensor({dataType:"float16",shape:[1,this._model.inputChannels,t,e],writable:!0},this._device)),u=this._resources.track("ml-tensor",await this._context.createExportableTensor({dataType:"float16",shape:[1,this._model.outputChannels,t,e],readable:!0},this._device)),l=this._resources.track("gpu-buffer",this._device.createBuffer({label:`oidn/webnn/output/${e}x${t}`,size:e*t*4*4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST})),p=this._resources.track("gpu-buffer",qi(this._device,`oidn/webnn/input/${e}x${t}`,[e,t,this._model.inputChannels])),c=this._resources.track("gpu-buffer",qi(this._device,`oidn/webnn/output/${e}x${t}`,[e,t])),{graph:a,inputTensor:s,outputTensor:u,outputBuffer:l,inputUniform:p,outputUniform:c,width:e,height:t,lastUsed:++this._clock}}catch(d){throw this._releaseBuffer(c),this._releaseBuffer(p),this._releaseBuffer(l),this._releaseTensor(u),this._releaseTensor(s),this._releaseGraph(a),d}}async _execution(e,t){const i=`${e}x${t}`;let n=this._shapeCache.get(i);if(!n){let o=this._shapePromises.get(i);o||(o=(async()=>{this._pendingCreationCount++;try{return await this._createExecution(e,t)}finally{this._pendingCreationCount--}})(),this._shapePromises.set(i,o));try{if(n=await o,this._disposed)throw this._destroyExecution(n),new Error("OIDN WebNN executor is disposed");this._shapeCache.set(i,n)}finally{this._shapePromises.get(i)===o&&this._shapePromises.delete(i)}if(this._shapeCache.size>this._shapeCacheSize){const a=[...this._shapeCache.entries()].filter(([s])=>s!==i).sort((s,u)=>s[1].lastUsed-u[1].lastUsed)[0];a&&(this._shapeCache.delete(a[0]),this._retireExecution(a[1]))}}return n.lastUsed=++this._clock,n}async prewarm(e){for(const t of e)await this._execution(t.width,t.height)}async execute(e,t,i){const n=this._model.inputChannels/3;if(e.length!==n)throw new Error(`OIDN WebNN expected ${n} input buffers, got ${e.length}`);const o=await this._execution(t,i),a=this._resources.track("gpu-buffer",await this._context.exportToGPU(o.inputTensor));try{const u=e.map((d,f)=>({binding:f,resource:{buffer:d}}));u.push({binding:n,resource:{buffer:a}}),u.push({binding:n+1,resource:{buffer:o.inputUniform}});const l=this._device.createBindGroup({label:"oidn/webnn/input-bindings",layout:this._inputPipeline.getBindGroupLayout(0),entries:u}),p=this._device.createCommandEncoder({label:"oidn/webnn/input-pack"}),c=p.beginComputePass();c.setPipeline(this._inputPipeline),c.setBindGroup(0,l),c.dispatchWorkgroups(Math.ceil(t/Pe),Math.ceil(i/Pe),this._model.inputChannels),c.end(),this._device.queue.submit([p.finish()])}finally{this._releaseBuffer(a)}this._context.dispatch(o.graph,{input:o.inputTensor},{output:o.outputTensor});const s=this._resources.track("gpu-buffer",await this._context.exportToGPU(o.outputTensor));try{const u=this._device.createBindGroup({label:"oidn/webnn/output-bindings",layout:this._outputPipeline.getBindGroupLayout(0),entries:[{binding:0,resource:{buffer:s}},{binding:1,resource:{buffer:o.outputBuffer}},{binding:2,resource:{buffer:o.outputUniform}}]}),l=this._device.createCommandEncoder({label:"oidn/webnn/output-unpack"}),p=l.beginComputePass();p.setPipeline(this._outputPipeline),p.setBindGroup(0,u),p.dispatchWorkgroups(Math.ceil(t/Pe),Math.ceil(i/Pe)),p.end(),this._device.queue.submit([l.finish()])}finally{this._releaseBuffer(s)}return o.outputBuffer}async executeCPU(e,t,i){const n=await this._execution(t,i),o=t*i,a=new D(o*this._model.inputChannels);for(let l=0;l<o;l++)for(let p=0;p<this._model.inputChannels;p++)a[p*o+l]=e[l*this._model.inputChannels+p];this._context.writeTensor(n.inputTensor,a),this._context.dispatch(n.graph,{input:n.inputTensor},{output:n.outputTensor});const s=new D(await this._context.readTensor(n.outputTensor)),u=new Float32Array(o*this._model.outputChannels);for(let l=0;l<o;l++)for(let p=0;p<this._model.outputChannels;p++)u[l*this._model.outputChannels+p]=s[p*o+l];return u}_destroyExecution(e){this._releaseGraph(e.graph),this._releaseTensor(e.inputTensor),this._releaseTensor(e.outputTensor),this._releaseBuffer(e.outputBuffer),this._releaseBuffer(e.inputUniform),this._releaseBuffer(e.outputUniform)}_retireExecution(e){this._retiredExecutions.add(e),this._device.queue.onSubmittedWorkDone().catch(()=>{}).then(()=>{this._retiredExecutions.delete(e),this._destroyExecution(e)})}_releaseBuffer(e){this._resources.release("gpu-buffer",e,()=>e.destroy())}_releaseTensor(e){this._resources.release("ml-tensor",e,()=>e.destroy())}_releaseGraph(e){this._resources.release("ml-graph",e,()=>e.destroy?.())}_releaseContext(){this._resources.release("ml-context",this._context,()=>this._context.destroy?.())}getResourceInfo(){return this._resources.snapshot(this._pendingCreationCount+this._retiredExecutions.size)}dispose(){if(!this._disposed){this._disposed=!0;for(const e of this._shapeCache.values())this._destroyExecution(e);this._shapeCache.clear();for(const e of this._retiredExecutions)this._destroyExecution(e);this._retiredExecutions.clear(),this._shapePromises.clear(),this._releaseContext()}}}const ca=100;function Me(r,e){return Math.ceil(r/e)*e}function wt(r){return r.data instanceof GPUBuffer||r.data instanceof GPUTexture}class la{_device;_aux;_hdr;_hdrTransfer;_dataProcessGPU;_nativeExecutor;_webNNExecutor;_modelSpec;_inputChannels;_engine;_dynamicTileController;_lastExecution;_profileNextImage=!1;_lastImageProfile;_activeExecutionFailures=new Set;_deviceLostObserved=!1;_deviceLostSettled=!1;_deviceLostReason;constructor(e,t,i={}){this._aux=i.aux||!1,this._hdr=i.hdr||!1,this._hdrTransfer=i.hdrTransfer??"pu",this._engine=i.engine??"auto";const n=i.modelSpec??gr(e),o=kn(e,n);this._modelSpec=o.spec,this._inputChannels=o.inputChannels;const a=this._aux?9:3;if(o.inputChannels!==a)throw new Error(`OIDN model expects ${o.inputChannels} input channels, but aux=${this._aux} provides ${a}`);this._dynamicTileController=new wn(i.maxTileSize??512,i.dynamicTile),this._device=t,this._observeDeviceLoss(),this._engine==="webnn"?this._webNNExecutor=new sa(this._device,o,{precision:i.precision}):this._nativeExecutor=new uo(this._device,o,{precision:i.precision,kernel:i.kernel,gemm:i.gemm,subgroupMatrix:i.subgroupMatrix})}getDevice(){return this._device}async prepare(){if(this._webNNExecutor){await this._webNNExecutor.prepare();const e=Me(this._modelSpec.receptiveField/2,Z),t=[this._dynamicTileController.tileSize,this._dynamicTileController.minTileSize];await this._webNNExecutor.prewarm([...new Set(t)].map(i=>({width:i+2*e,height:i+2*e})));return}await this._nativeExecutor.prepare()}async prepareForImage(e,t,i={}){const n=Me(this._modelSpec.receptiveField/2,Z),o=i.tileOverlap===void 0?n:Me(Math.max(0,i.tileOverlap),Z),a=vi(e,t,i.wholeImage?Me(Math.max(e,t),Z):this._dynamicTileController.tileSize,o),s=[...new Map(a.tiles.map(({input:u})=>[`${u.width}x${u.height}`,{width:u.width,height:u.height}])).values()];await this._webNNExecutor?.prewarm(s),this._nativeExecutor?.prewarm(s)}getRuntimeInfo(){return{configuredEngine:this._engine,gpuEngine:this._webNNExecutor?"webnn":"wgsl",precision:(this._webNNExecutor??this._nativeExecutor).precision,kernel:this._nativeExecutor?{configured:this._nativeExecutor.kernelSetting,gemm:this._nativeExecutor.gemm,maxSpatialInputBlocks:this._nativeExecutor.maxSpatialInputBlocks,subgroupsAvailable:this._nativeExecutor.subgroupsAvailable,subgroupMatrix:this._nativeExecutor.subgroupMatrix}:void 0,webnn:this._webNNExecutor?.support,resources:(this._webNNExecutor??this._nativeExecutor).getResourceInfo(),model:this._modelSpec.id,modelFamily:this._modelSpec.family,inputChannels:this._inputChannels,hdrTransfer:this._hdrTransfer,dynamicTile:{enabled:this._dynamicTileController.enabled,currentTileSize:this._dynamicTileController.tileSize,minTileSize:this._dynamicTileController.minTileSize,maxTileSize:this._dynamicTileController.maxTileSize,targetTileTimeMs:this._dynamicTileController.targetTileTimeMs},lastExecution:this._lastExecution,activeExecutionCount:this._activeExecutionFailures.size}}_observeDeviceLoss(){if(this._activeExecutionFailures??=new Set,this._deviceLostObserved)return;this._deviceLostObserved=!0;const e=this._device.lost;if(!e)return;const t=i=>{if(this._deviceLostSettled)return;this._deviceLostSettled=!0,this._deviceLostReason=i;const n=[...this._activeExecutionFailures];this._activeExecutionFailures.clear();for(const o of n)o(i)};e.then(i=>t(new Error(`WebGPU device lost: ${i.message}`)),t)}_registerExecutionFailure(e){return this._observeDeviceLoss(),this._activeExecutionFailures.add(e),this._deviceLostSettled&&(this._activeExecutionFailures.delete(e),queueMicrotask(()=>e(this._deviceLostReason))),()=>this._activeExecutionFailures.delete(e)}profileNextExecution(){return!this._nativeExecutor||!this._device.features.has("timestamp-query")?!1:(this._profileNextImage=!0,!0)}getLastExecutionProfile(){return this._lastImageProfile?Promise.resolve(this._lastImageProfile):void 0}_processImageData(e,t,i,n){const o=e.data,a=o.length/4,s=this._aux?9:3,u=new Float32Array(a*s);if(t&&!i||i&&!t)throw new Error("Normal map and albedo map are both required");if(t&&i&&(t.width!==i.width||t.height!==i.height||e.width!==t.width||e.height!==t.height))throw new Error("Image size mismatch");const l=t?.data,p=i?.data,c=l instanceof Float32Array?1:255,d=p instanceof Float32Array?1:255;for(let f=0;f<o.length;f+=4){const g=f/4*s;for(let h=0;h<3;h++)n?u[g+h]=o[f+h]:u[g+h]=o[f+h]/255,l&&(u[g+h+3]=l[f+h]/c),p&&(u[g+h+6]=p[f+h]/d)}return u}_readTile(e,t,i,n){const o=new Float32Array(i.width*i.height*t),a=e.length/(n*t);for(let s=0;s<i.height;s++)for(let u=0;u<i.width;u++){const l=Math.min(n-1,u+i.x),c=(Math.min(a-1,s+i.y)*n+l)*t,d=(s*i.width+u)*t;for(let f=0;f<t;f++)o[d+f]=e[c+f]}return o}_writeTile(e,t,i,n,o,a){const{data:s,width:u}=e,l=i.x-t.x,p=i.y-t.y;for(let c=0;c<i.height;c++)for(let d=0;d<i.width;d++){const f=((c+p)*o+d+l)*3,g=((c+i.y)*u+(d+i.x))*4;for(let h=0;h<3;h++)a?s[g+h]=n[f+h]:s[g+h]=Math.min(Math.max(n[f+h]*255,0),255);e.data[g+3]=a?1:255}}async _executeTile(e,t,i,n,o,a,s,u,l){const p=this._aux?9:3,c=new Ut(n.input.x,n.input.y,n.input.width,n.input.height),d=new Ut(n.output.x,n.output.y,n.output.width,n.output.height),f=c.width,g=c.height;let h,_,$=1;const w=this._device;let y=this._dataProcessGPU;if(e instanceof Float32Array){let m=this._readTile(e,p,c,a);u&&($=pn({data:m,channels:p}),m=cn({data:m,channels:p,inputScale:$,transfer:this._hdrTransfer})),_=await(this._webNNExecutor??this._nativeExecutor).executeCPU(m,f,g)}else{y||(y=this._dataProcessGPU=new fn(w,u,this._hdrTransfer)),y.setImageSize(a,s),y.setInputTile(c),o&&y.copyInputDataToOutput(e.color);const{color:m,albedo:v,normal:x}=y.forward(e.color,this._aux?e.albedo:void 0,this._aux?e.normal:void 0,l);h=await(this._webNNExecutor??this._nativeExecutor).execute(this._aux?[m,v,x]:[m],f,g)}let b;if(e instanceof Float32Array){u&&(_=ln({data:_,channels:3,inputScale:$,transfer:this._hdrTransfer})),this._writeTile(i,c,d,_,c.width,u);for(let m=0;m<d.height;m++)for(let v=0;v<d.width;v++){const x=(m*d.width+v)*4,k=((m+d.y)*a+(v+d.x))*4;for(let B=0;B<4;B++)t.data[x+B]=i.data[k+B]}}else y.setOutputTile(d,c),b=y.inverse(h,e.color);return b}tileExecute({color:e,albedo:t,normal:i,done:n,progress:o,denoiseAlpha:a,tileOverlap:s,wholeImage:u,scheduling:l="event-loop",error:p}){if(this._aux&&(!t||!i))throw new Error("Normal map and albedo map are both required");if(!this._aux&&(t||i))throw new Error("Normal map and albedo map are not required");const c=e.width,d=e.height,f=this._dynamicTileController.tileSize,g=u?Me(Math.max(c,d),Z):f,h=Me(this._modelSpec.receptiveField/2,Z),_=s===void 0?h:Me(Math.max(0,s),Z),$=vi(c,d,g,_),w=$.tiles.length>1,y=this._hdr||!1;let b;wt(e)||(b=this._processImageData(e,t,i,y));function m(R,V){return y?{data:new Float32Array(R*V*4),width:R,height:V}:new ImageData(R,V)}const v=wt(e)?void 0:m(c,d);let x="active",k,B,P=()=>!1;const T=()=>typeof performance>"u"?Date.now():performance.now(),U=T(),j=[],ne=this._profileNextImage===!0;this._profileNextImage=!1;const ie=new Map,pe=()=>{k!==void 0&&(clearTimeout(k),k=void 0),B!==void 0&&typeof cancelAnimationFrame<"u"&&(cancelAnimationFrame(B),B=void 0)},K=R=>{console.error("OIDN error callback failed",R)},te=R=>{if(x==="active")if(x="settled",pe(),P(),p)try{Promise.resolve(p(R)).catch(K)}catch(V){K(V)}else console.error("OIDN execution failed",R)},be=R=>{if(l==="event-loop"||typeof requestAnimationFrame>"u")k=setTimeout(()=>{k=void 0,R()},0);else{const V=()=>{pe(),R()};B=requestAnimationFrame(V),k=setTimeout(V,ca)}},Ue=async R=>{if(x!=="active")return;const V=$.tiles[R],Se=wt(e)?void 0:m(V.output.width,V.output.height),We=T();ne&&this._nativeExecutor.profileNextExecution();const De=await this._executeTile(wt(e)?{color:e.data,albedo:t?.data,normal:i?.data}:b,Se,v,V,R===0,c,d,y,a);if(ne){const W=await this._nativeExecutor.getLastExecutionProfile();for(const G of W?.layers??[])ie.set(G.id,(ie.get(G.id)??0)+G.durationMs)}if(x!=="active")return;const Le=v||{data:De,width:c,height:d};if(o&&await o(Le,Se,new Ut(V.output.x,V.output.y,V.output.width,V.output.height),R,$.tiles.length),x!=="active")return;const A=R+1<$.tiles.length;if(await this._device.queue.onSubmittedWorkDone(),x!=="active")return;await(async()=>{if(j.push(T()-We),x==="active")if(A)be(()=>{x==="active"&&Ue(R+1).catch(te)});else{const W=[...j].sort((ke,ge)=>ke-ge),G=Math.floor(W.length/2),Ce=W.length%2?W[G]:(W[G-1]+W[G])/2;if(this._lastExecution={width:c,height:d,tileCount:$.tiles.length,tileColumns:$.columns,tileRows:$.rows,tileOverlap:$.overlap,inputPixelCount:$.inputPixelCount,inputShapeCount:$.inputShapeCount,durationMs:T()-U,tileTimeMs:{min:W[0],median:Ce,mean:W.reduce((ke,ge)=>ke+ge,0)/W.length,max:W[W.length-1]}},w&&this._dynamicTileController.observe(j),P(),ne){const ke=[...ie].map(([ge,Qe])=>({id:ge,durationMs:Qe}));this._lastImageProfile={totalMs:ke.reduce((ge,Qe)=>ge+Qe.durationMs,0),layers:ke}}await n(Le),x==="active"&&(x="settled")}})()};return P=this._registerExecutionFailure(te),Ue(0).catch(te),()=>{x==="active"&&(x="aborted",pe(),P())}}dispose(){this._dataProcessGPU?.dispose(),this._nativeExecutor?.dispose(),this._webNNExecutor?.dispose()}}async function pa(){if(!navigator.gpu)throw new Error("WebGPU is not available");const r={powerPreference:"high-performance"},e=await navigator.gpu.requestAdapter(r);if(!e)throw new Error("No WebGPU adapter is available");const t={},i=[];e.features.has("timestamp-query")&&i.push("timestamp-query"),e.features.has("bgra8unorm-storage")&&i.push("bgra8unorm-storage"),e.features.has("shader-f16")&&i.push("shader-f16");for(const o of["subgroups","chromium-experimental-subgroup-matrix"])e.features.has(o)&&i.push(o);t.requiredFeatures=i;const n=e.limits;return t.requiredLimits={maxComputeWorkgroupStorageSize:n.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:n.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:n.maxStorageBufferBindingSize,maxBufferSize:n.maxBufferSize,maxComputeWorkgroupSizeX:n.maxComputeWorkgroupSizeX,maxComputeInvocationsPerWorkgroup:n.maxComputeInvocationsPerWorkgroup},e.requestDevice(t)}async function Ft(r,e,t){const i=e?.device??await pa(),n=nn(r),o=new la(n,i,t);return await o.prepare(),o}const da=new URL(""+new URL("rt_hdr_alb_nrm-e586ef2f.tza",import.meta.url).href,self.location),ha=new URL(""+new URL("rt_hdr_alb_nrm_small-980ea307.tza",import.meta.url).href,self.location),fa={small:"rt_hdr_alb_nrm_small.tza",standard:"rt_hdr_alb_nrm.tza",cleanAuxLarge:"rt_hdr_calb_cnrm_large.tza"},Zi={albedo:"rt_alb_large.tza",normal:"rt_nrm_large.tza"},Kr="oidn-weights",ga="2.3.0-1",qr=`https://cdn.jsdelivr.net/npm/${Kr}@${ga}/`,ma=`https://cdn.jsdelivr.net/npm/@meimu/mutracer@${Jr}/oidn/weights/`;function Qi(r,e){if(e===void 0){if(r==="standard")return String(da);if(r==="small")return String(ha)}const t=e??qr,i=typeof t=="string"?t:String(t);return`${i}${i.endsWith("/")?"":"/"}${fa[r]}`}function Ji(r=qr){const e=typeof r=="string"?r:String(r),t=`${e}${e.endsWith("/")?"":"/"}`;return{albedo:`${t}${Zi.albedo}`,normal:`${t}${Zi.normal}`}}async function Jt(r,e){const t=await fetch(String(r),{signal:e});if(!t.ok)throw new Error(`Failed to load OIDN weights from ${r}: ${t.status} ${t.statusText}`);const i=await t.arrayBuffer(),n=new Uint8Array(i);if(n[0]!==215||n[1]!==65)throw new Error(`Invalid OIDN TZA weights from ${r}: expected magic D7 41 (received non-TZA content).`);return i}async function Zr(r,e,t={},i=Jt){await r.init();const n=r.device;if(r.backend!=="webgpu"||!n)throw new Error("OIDN requires a WebGPU engine.");const o=t.auxiliaryModelUrls,a=await Promise.all([r._getWeights(String(e),()=>i(e,t.signal)),...o?[r._getWeights(String(o.albedo),()=>i(o.albedo,t.signal)),r._getWeights(String(o.normal),()=>i(o.normal,t.signal))]:[]]),s={device:n},u={hdrTransfer:t.hdrTransfer??"pu",maxTileSize:t.maxTileSize,engine:t.engine,precision:t.precision,dynamicTile:t.dynamicTile};let l,p;try{if(l=await Ft(a[0],s,{aux:t.aux??!0,hdr:t.hdr??!0,...u}),o){p=await Ft(a[1],s,{aux:!1,hdr:!1,...u});const c=await Ft(a[2],s,{aux:!1,hdr:!1,...u});l.auxiliaryDenoisers={albedo:p,normal:c}}}catch(c){throw p?.dispose(),l?.dispose(),c}return l}function $a(r,e,t={}){return Zr(r,e,t)}let er=!1;function _a(r,e={}){const{model:t="standard",weightsBaseUrl:i,auxiliaryModelUrls:n,...o}=e,a=Qi(t,i),s=i===void 0&&t!=="cleanAuxLarge",u=new Set(i===void 0&&t==="cleanAuxLarge"?[a,...n?[]:Object.values(Ji()).map(String)]:[]),l=async(p,c)=>{try{return await Jt(p,c)}catch(d){if(c?.aborted)throw d;if(s&&String(p)===a)return er||(er=!0,console.warn('Bundled OIDN weights failed to load; falling back to jsDelivr. In Vite development add optimizeDeps: { exclude: ["@meimu/mutracer"] }, or pass weightsBaseUrl to self-host the weights.',d)),Jt(Qi(t,ma),c);throw u.has(String(p))?new Error(`Failed to load ${Kr} network from ${p}. Self-host node_modules/oidn-weights/*.tza and pass weightsBaseUrl. ${d instanceof Error?d.message:String(d)}`):d}};return Zr(r,a,{...o,auxiliaryModelUrls:n??(t==="cleanAuxLarge"?Ji(i):void 0)},l)}function va(r,e){return e.weightsUrl!==void 0?$a(r,e.weightsUrl,e):_a(r,e)}export{va as loadOIDNNetwork};
